<div class="n-layout__row n-layout__row--content">

    <main id="site-content">
        <div data-trackable="list:top-stories;listTitle:empty" data-trackable-context-list-type="top-stories"
            data-trackable-context-list-position="0" data-trackable-context-list-siblings="20"
            class="story-group-slice">
            <section class="slice story-group-named-slice top-stories-slice slice__no-title slice--default">
                <div class="slice__content">
                    <div class="layout-desktop__grid-container">

                        <div
                            class="layout-desktop__grid layout-desktop__grid--span4 layout-desktop__grid--column-start-1 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:oil-and-gas-industry;storyGroup:small"
                                    data-trackable-context-storygroup-size="small"
                                    data-trackable-context-storygroup-title="oil-and-gas-industry"
                                    data-trackable-context-storygroup-position="0"
                                    data-trackable-context-storygroup-siblings="3" class="layout-desktop--full-height">
                                    <div class="story-group-stacked">
                                        <?php

                                            foreach (array_slice($featured,0,2) as $key => $value):

                                                $CategoryName = $categories[$value->CatId]['TermName'];
                                                $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                                                $slug = base_url($value->PostSlug);
                                                $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                                                $title = strlen($post_title) > 45 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 20)) . '...' : $post_title;
                                                $thumb_url = $value->PostThumbUrl;
                                                $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 40));
                                                ?>
                                        <div class="story-group-stacked__primary-story">
                                            <div class="story-group__article story-group__article--lead">
                                                <div data-trackable="story:lead"
                                                    data-trackable-context-story-type="lead"
                                                    data-trackable-context-story-position="0"
                                                    data-trackable-context-story-siblings="3"
                                                    class="grid grid--3-columns grid--s4-spacing grid--fullHeight">
                                                    <div class="grid-item grid-item--span-3">
                                                        <div class="grid grid--1-columns grid--s3-spacing">
                                                            <div class="primary-story__teaser">
                                                                <div class="story-group__title"><a
                                                                        data-trackable="story-group-title-link"
                                                                        data-trackable-context-story-link="story-group-title-link"
                                                                        href="<?= $CategorySlug?>" class="link"
                                                                        target="_self" aria-hidden="false"><span
                                                                            class="text text--color-claret text-sans--scale-0 text--weight-600"
                                                                            id=""><?= $CategoryName?></span></a></div>
                                                                <div class="headline js-teaser-headline headline--scale-7 headline--color-black"
                                                                    data-content-id="f4b89276-efcf-4731-9ed3-7afea3be4c27">
                                                                    <a data-trackable="heading-link"
                                                                        data-trackable-context-story-link="heading-link"
                                                                        href="<?= $slug?>" class="link" target="_self"
                                                                        aria-hidden="false"><span
                                                                            class="text text--color-black text-display--scale-7 text--weight-500"
                                                                            id=""><?=  $post_title ?></span></a>
                                                                </div>
                                                                <p class="standfirst"><a
                                                                        data-trackable="standfirst-link"
                                                                        data-trackable-context-story-link="standfirst-link"
                                                                        href="<?= $slug?>" class="link" target="_self"
                                                                        aria-hidden="false"><span
                                                                            class="text text--color-black-60 text-sans--scale-0 text--style--no-active-state"
                                                                            id=""><?= $content?></span></a></p>
                                                            </div>
                                                            <div
                                                                class="grid-item grid-item--span-1 grid-item--align-self-end">
                                                                <div class="metadata metadata__timestamp">
                                                                    <div class="timestamp"><time
                                                                            class="timestamp-date o-date"
                                                                            data-o-component="o-date"
                                                                            data-o-date-format="time-ago-limit-4-hours"
                                                                            datetime="2023-05-08T04:00:26+0000">2
                                                                            hours ago</time></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="separator--solid"></div>
                                            </div>
                                        </div>

                                        <?php endforeach;?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php    
                                                $CategoryName = $categories[$featured[2]->CatId]['TermName'];
                                                $CategorySlug = base_url('category/' . $categories[$featured[2]->CatId]['TermSlug']);
                                                $slug = base_url($featured[2]->PostSlug);
                                                $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $featured[2]->PostTitle);
                                              
                                                $thumb_url = $featured[2]->PostThumbUrl;
                                                $content = implode(' ', array_slice(explode(' ', strip_tags($featured[2]->PostContent)), 0, 40));?>
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span6 layout-desktop__grid--column-start-5 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:law;storyGroup:medium"
                                    data-trackable-context-storygroup-size="medium"
                                    data-trackable-context-storygroup-title="law"
                                    data-trackable-context-storygroup-position="1"
                                    data-trackable-context-storygroup-siblings="3" class="layout-desktop--full-height">
                                    <div class="story-group story-group--featured">
                                        <div class="grid grid--2-columns grid--fullHeight"
                                            style="grid-template-rows:auto;-ms-grid-rows:auto">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-2 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--featured">
                                                    <div data-trackable="story:featured"
                                                        data-trackable-context-story-type="featured"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="1"
                                                        class="featured-story featured-story--theme-tinted">
                                                        <div class="featured-story__image"><a
                                                                data-trackable="image-link"
                                                                data-trackable-context-story-link="image-link"
                                                                href="<?= $slug?>" class="link" target="_self"
                                                                tabindex="-1" aria-hidden="true">
                                                                <img data-src="<?= $thumb_url;?>"
                                                                    alt="<?= $post_title?>"
                                                                    class="image image--width-580 lazy">
                                                            </a></div>
                                                        <div class="featured-story-content">
                                                            <div class="story-group__title"><a
                                                                    data-trackable="story-group-title-link"
                                                                    data-trackable-context-story-link="story-group-title-link"
                                                                    href="<?= $CategorySlug;?>" class="link"
                                                                    target="_self" aria-hidden="false"><span
                                                                        class="text text--color-claret text-sans--scale-0 text--weight-600"
                                                                        id=""><?= $CategoryName;?></span></a></div>
                                                            <div class="headline js-teaser-headline headline--scale-5 headline--color-black"
                                                                data-content-id="cc8f0c01-d6d8-4fe1-a141-5bc92f1c1096">
                                                                <a data-trackable="heading-link"
                                                                    data-trackable-context-story-link="heading-link"
                                                                    href="<?= $slug?>" class="link" target="_self"
                                                                    aria-hidden="false"><span
                                                                        class="text text--color-black text-display--scale-5 text--weight-400"
                                                                        id=""><?= $post_title?></span></a>
                                                                <p><?= $content?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-group__separator story-group__separator--hidden">
                                                    <div class="separator--solid"></div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span2 layout-desktop__grid--column-start-11 layout-desktop__grid--row-start-1 layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:editor-s-picks;storyGroup:xsmall"
                                    data-trackable-context-storygroup-size="xsmall"
                                    data-trackable-context-storygroup-title="editor-s-picks"
                                    data-trackable-context-storygroup-position="2"
                                    data-trackable-context-storygroup-siblings="3" class="layout-desktop--full-height">
                                    <div class="story-group story-group--extra-small">
                                        <div class="grid grid--1-columns grid--fullHeight"
                                            style="grid-template-rows:min-content;-ms-grid-rows:min-content">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-0 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--lead">
                                                    <div data-trackable="story:lead"
                                                        data-trackable-context-story-type="lead"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="2"
                                                        class="grid grid--1-columns grid--s4-spacing grid--fullHeight">
                                                        <div class="grid-item grid-item--span-1">
                                                            <div class="grid grid--1-columns grid--s3-spacing">
                                                                <?php

                                                        foreach (array_slice($featured,3) as $key => $value):

                                                            $CategoryName = $categories[$value->CatId]['TermName'];
                                                            $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                                                            $slug = base_url($value->PostSlug);
                                                            $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                                                            $title = strlen($post_title) > 45 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 20)) . '...' : $post_title;
                                                            $thumb_url = $value->PostThumbUrl;
                                                            // $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 40));
                                                            ?>
                                                                <div class="primary-story__teaser">
                                                                    <div class="story-group__title">
                                                                        <a data-trackable="story-group-title-link"
                                                                            data-trackable-context-story-link="story-group-title-link"
                                                                            href="<?= $CategorySlug?>" class="link"
                                                                            target="_self" aria-hidden="false">
                                                                            <span
                                                                                class="text text--color-claret text-sans--scale-0 text--weight-400"
                                                                                id=""><?=  $CategoryName?></span></a>
                                                                    </div>
                                                                    <div
                                                                        class="primary-story__image primary-story__image--1-cols">
                                                                        <a data-trackable="image-link"
                                                                            data-trackable-context-story-link="image-link"
                                                                            href="<?= $slug;?>" class="link"
                                                                            target="_self" tabindex="-1"
                                                                            aria-hidden="true">
                                                                            <img data-src="<?= $thumb_url;?>"
                                                                                alt="<?= $post_title?>"
                                                                                class="image image--width-180 lazy">
                                                                        </a>
                                                                    </div>

                                                                    <div class="headline js-teaser-headline headline--scale-3 headline--color-black"
                                                                        data-content-id="9e6d7b88-de6c-4f50-a41e-c5ff39d31286">
                                                                        <a data-trackable="heading-link"
                                                                            data-trackable-context-story-link="heading-link"
                                                                            href="<?= $slug;?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                placeholder="headlineIndicator"
                                                                                class="headline-indicator"><span
                                                                                    class="text text--color-black text-display--scale-3 text--weight-500"
                                                                                    id=""><?= $post_title?></span></a>
                                                                    </div>
                                                                </div>
                                                                <div class="story-group__separator">
                                                                    <div class="separator--solid"></div>
                                                                </div>
                                                                <?php endforeach;?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php if ($settings->HeaderAds): ?>
        <section class="slice advert-slice slice__no-title">
            <div class="slice__content">
                <div class="layout-tablet__grid-container">
                    <div
                        class="layout-tablet__grid layout-tablet__grid--span12 layout-tablet__grid--column-start-1 layout-tablet__grid--row-start-1">
                        <div class="layout__grid-content">


                            <!--AD Body Start-->
                            <?php if (!empty($_GET['static'])) {?>
                            <div id="advertize_content"> Advertize Content One
                                <?=$settings->HeaderAds;?>
                            </div>
                            <?php } else {?>
                            <?=$settings->HeaderAds;?>
                            <?php }?>
                            <!--AD Body End-->


                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif;?>
        <div data-trackable="list:top-stories;listTitle:top-stories" data-trackable-context-list-type="top-stories"
            data-trackable-context-list-position="2" data-trackable-context-list-siblings="20"
            class="story-group-slice">
            <section class="slice top-stories-slice slice--default">
                <div class="slice__content">
                    <div class="separator--dotted"></div>
                    <header id="top-stories" class="slice-heading">
                        <h2 class="slice-heading__title"><span class="text text--color-black-80 text-sans--scale-0"
                                id="">Top
                                stories</span></h2>
                    </header>
                    <div class="layout-desktop__grid-container">
                        <?php
                        // $HomeData;
                        // $top_stories = $controller->posts(5, 4, array('PostContent'));
                        $top_stories = array_slice($HomeData,0,4);
                        foreach ($top_stories as $key => $value):
                        
                        $CategoryName = $categories[$value->CatId]['TermName'];
                        $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                        $slug = base_url($value->PostSlug);
                        $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                        // $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : "<br>" . $post_title;
                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                        $thumb_url = $value->PostThumbUrl;
                        ?>
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span3 layout-desktop__grid--column-start-1 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:anheuser-busch-inbev-sa;storyGroup:small"
                                    data-trackable-context-storygroup-size="small"
                                    data-trackable-context-storygroup-title="anheuser-busch-inbev-sa"
                                    data-trackable-context-storygroup-position="0"
                                    data-trackable-context-storygroup-siblings="4" class="layout-desktop--full-height">
                                    <div class="story-group">
                                        <div class="grid grid--1-columns grid--fullHeight"
                                            style="grid-template-rows:min-content;-ms-grid-rows:min-content">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-1 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--lead">
                                                    <div data-trackable="story:lead"
                                                        data-trackable-context-story-type="lead"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="1"
                                                        class="grid grid--3-columns grid--s4-spacing grid--fullHeight">
                                                        <div class="grid-item grid-item--span-3">
                                                            <div class="grid grid--1-columns grid--s3-spacing">
                                                                <div
                                                                    class="primary-story__image primary-story__image--1-cols">
                                                                    <a data-trackable="image-link"
                                                                        data-trackable-context-story-link="image-link"
                                                                        href="<?= $slug?>" class="link" target="_self"
                                                                        tabindex="-1" aria-hidden="true">
                                                                        <img data-src="<?= $thumb_url;?>"
                                                                            alt="<?= $post_title?>"
                                                                            class="image image--width-280 lazy">

                                                                    </a>
                                                                </div>
                                                                <div class="primary-story__teaser">
                                                                    <div class="story-group__title"><a
                                                                            data-trackable="story-group-title-link"
                                                                            data-trackable-context-story-link="story-group-title-link"
                                                                            href="<?= $CategorySlug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-claret text-sans--scale-0 text--weight-600"
                                                                                id=""><?= $CategoryName?></span></a>
                                                                    </div>
                                                                    <div class="headline js-teaser-headline headline--scale-3 headline--color-black"
                                                                        data-content-id="dc63c64c-d32e-460a-afdc-458c94860c93">
                                                                        <a data-trackable="heading-link"
                                                                            data-trackable-context-story-link="heading-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black text-display--scale-3 text--weight-500"
                                                                                id=""><?= $post_title?></span></a>
                                                                    </div>
                                                                    <p class="standfirst"><a
                                                                            data-trackable="standfirst-link"
                                                                            data-trackable-context-story-link="standfirst-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black-60 text-sans--scale-0 text--style--no-active-state"
                                                                                id=""><?= $content?> </span></a></p>
                                                                </div>
                                                                <div
                                                                    class="grid-item grid-item--span-1 grid-item--align-self-end">
                                                                    <div class="metadata metadata__timestamp">
                                                                        <div class="timestamp"><time
                                                                                class="timestamp-date o-date"
                                                                                data-o-component="o-date"
                                                                                data-o-date-format="time-ago-limit-4-hours"
                                                                                datetime="2023-05-08T04:00:27+0000">2
                                                                                hours ago</time></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="story-group__separator story-group__separator--hidden">
                                                    <div class="separator--solid"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach?>

                    </div>
                    <div class="story-group__separator story-group__separator--hidden">
                        <div class="separator--solid"></div>
                    </div>
                    <div class="layout-desktop__grid-container">
                        <?php
                        //$top_stories = $controller->posts(9, 4, array('PostContent'));
                        $top_stories = array_slice($HomeData,5,4);
                        foreach ($top_stories as $key => $value):
                        
                        $CategoryName = $categories[$value->CatId]['TermName'];
                        $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                        $slug = base_url($value->PostSlug);
                        $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                        // $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : "<br>" . $post_title;
                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                        $thumb_url = $value->PostThumbUrl;
                        ?>
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span3 layout-desktop__grid--column-start-1 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:anheuser-busch-inbev-sa;storyGroup:small"
                                    data-trackable-context-storygroup-size="small"
                                    data-trackable-context-storygroup-title="anheuser-busch-inbev-sa"
                                    data-trackable-context-storygroup-position="0"
                                    data-trackable-context-storygroup-siblings="4" class="layout-desktop--full-height">
                                    <div class="story-group">
                                        <div class="grid grid--1-columns grid--fullHeight"
                                            style="grid-template-rows:min-content;-ms-grid-rows:min-content">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-1 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--lead">
                                                    <div data-trackable="story:lead"
                                                        data-trackable-context-story-type="lead"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="1"
                                                        class="grid grid--3-columns grid--s4-spacing grid--fullHeight">
                                                        <div class="grid-item grid-item--span-3">
                                                            <div class="grid grid--1-columns grid--s3-spacing">
                                                                <div
                                                                    class="primary-story__image primary-story__image--1-cols">
                                                                    <a data-trackable="image-link"
                                                                        data-trackable-context-story-link="image-link"
                                                                        href="<?= $slug?>" class="link" target="_self"
                                                                        tabindex="-1" aria-hidden="true">
                                                                        <img data-src="<?= $thumb_url;?>"
                                                                            alt="<?= $post_title?>"
                                                                            class="image image--width-280 lazy">
                                                                    </a>
                                                                </div>
                                                                <div class="primary-story__teaser">
                                                                    <div class="story-group__title"><a
                                                                            data-trackable="story-group-title-link"
                                                                            data-trackable-context-story-link="story-group-title-link"
                                                                            href="<?= $CategorySlug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-claret text-sans--scale-0 text--weight-600"
                                                                                id=""><?= $CategoryName?></span></a>
                                                                    </div>
                                                                    <div class="headline js-teaser-headline headline--scale-3 headline--color-black"
                                                                        data-content-id="dc63c64c-d32e-460a-afdc-458c94860c93">
                                                                        <a data-trackable="heading-link"
                                                                            data-trackable-context-story-link="heading-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black text-display--scale-3 text--weight-500"
                                                                                id=""><?= $post_title?></span></a>
                                                                    </div>
                                                                    <p class="standfirst"><a
                                                                            data-trackable="standfirst-link"
                                                                            data-trackable-context-story-link="standfirst-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black-60 text-sans--scale-0 text--style--no-active-state"
                                                                                id=""><?= $content?></span></a></p>
                                                                </div>
                                                                <div
                                                                    class="grid-item grid-item--span-1 grid-item--align-self-end">
                                                                    <div class="metadata metadata__timestamp">
                                                                        <div class="timestamp"><time
                                                                                class="timestamp-date o-date"
                                                                                data-o-component="o-date"
                                                                                data-o-date-format="time-ago-limit-4-hours"
                                                                                datetime="2023-05-08T04:00:27+0000">2
                                                                                hours ago</time></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="story-group__separator story-group__separator--hidden">
                                                    <div class="separator--solid"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach?>

                    </div>
                </div>
            </section>
        </div>
        <section class="slice advert-slice slice__no-title">
            <div class="slice__content">
                <div class="layout-tablet__grid-container">
                    <div
                        class="layout-tablet__grid layout-tablet__grid--span12 layout-tablet__grid--column-start-1 layout-tablet__grid--row-start-1">
                        <div class="layout__grid-content">
                            <div class="o-ads o-ads--center o-ads--transition o-ads--center" data-o-ads-init="true"
                                data-o-ads-name="mid-desktop" data-o-ads-targeting="pos=mid"
                                data-o-ads-formats="MediumRectangle"
                                data-o-ads-formats-default="MediumRectangle,OneByOne,Responsive"
                                data-o-ads-formats-small="false"
                                data-o-ads-formats-medium="Leaderboard,OneByOne,Responsive"
                                data-o-ads-formats-large="SuperLeaderboard,Leaderboard,Billboard,OneByOne,Responsive"
                                data-o-ads-formats-extra="SuperLeaderboard,Leaderboard,Billboard,OneByOne,Responsive">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div data-trackable="list:top-stories;listTitle:news" data-trackable-context-list-type="top-stories"
            data-trackable-context-list-position="7" data-trackable-context-list-siblings="20"
            class="story-group-slice">
            <section class="slice top-stories-slice slice--default">
                <div class="slice__content">
                    <div class="separator--dotted"></div>
                    <header id="news" class="slice-heading">
                        <h2 class="slice-heading__title"><span class="text text--color-black-80 text-sans--scale-0"
                                id="">NEWS</span></h2>
                    </header>
                </div>
            </section>
        </div>
        <div data-trackable="list:top-stories;listTitle:empty" data-trackable-context-list-type="top-stories"
            data-trackable-context-list-position="8" data-trackable-context-list-siblings="20"
            class="story-group-slice">
            <section class="slice top-stories-slice slice__no-title slice--default">
                <div class="slice__content">
                    <div class="separator--solid"></div>
                    <div class="layout-desktop__grid-container">
                        <?php
                        // $top_stories = $controller->posts(13, 4, array('PostContent'));
                        $top_stories = array_slice($HomeData,9,4);
                        foreach ($top_stories as $key => $value):
                        $class_name = $key%2==0?'story-group--featured':'';
                        $CategoryName = $categories[$value->CatId]['TermName'];
                        $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                        $slug = base_url($value->PostSlug);
                        $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                        // $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : "<br>" . $post_title;
                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                        $thumb_url = $value->PostThumbUrl;
                        ?>
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span3 layout-desktop__grid--column-start-1 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:sudan;storyGroup:small"
                                    data-trackable-context-storygroup-size="small"
                                    data-trackable-context-storygroup-title="sudan"
                                    data-trackable-context-storygroup-position="0"
                                    data-trackable-context-storygroup-siblings="4" class="layout-desktop--full-height">
                                    <div class="story-group <?= $class_name?>">
                                        <div class="grid grid--1-columns grid--fullHeight"
                                            style="grid-template-rows:min-content;-ms-grid-rows:min-content">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-1 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--lead">
                                                    <div data-trackable="story:lead"
                                                        data-trackable-context-story-type="lead"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="1"
                                                        class="grid grid--3-columns grid--s4-spacing grid--fullHeight">
                                                        <div class="grid-item grid-item--span-3">
                                                            <div class="grid grid--1-columns grid--s3-spacing">
                                                                <div
                                                                    class="primary-story__image primary-story__image--1-cols">
                                                                    <a data-trackable="image-link"
                                                                        data-trackable-context-story-link="image-link"
                                                                        href="<?= $slug?>" class="link" target="_self"
                                                                        tabindex="-1" aria-hidden="true">
                                                                        <img data-src="<?= $thumb_url?>"
                                                                            alt="<?= $post_title?>"
                                                                            class="image image--width-280 lazy">
                                                                    </a>
                                                                </div>
                                                                <div class="primary-story__teaser">
                                                                    <div class="story-group__title"><a
                                                                            data-trackable="story-group-title-link"
                                                                            data-trackable-context-story-link="story-group-title-link"
                                                                            href="<?= $CategorySlug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-claret text-sans--scale-0 text--weight-600"
                                                                                id=""><?= $CategoryName?></span></a>
                                                                    </div>
                                                                    <div class="headline js-teaser-headline headline--scale-3 headline--color-black"
                                                                        data-content-id="24c1e082-f5fe-43d0-9a9c-a4de431ce0f6">
                                                                        <a data-trackable="heading-link"
                                                                            data-trackable-context-story-link="heading-link"
                                                                            href="<?=$slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black text-display--scale-3 text--weight-500"
                                                                                id=""><?= $post_title?></span></a>
                                                                    </div>
                                                                    <p class="standfirst"><a
                                                                            data-trackable="standfirst-link"
                                                                            data-trackable-context-story-link="standfirst-link"
                                                                            href="<?=$slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black-60 text-sans--scale-0 text--style--no-active-state"
                                                                                id=""><?= $content?></span></a></p>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="story-group__separator story-group__separator--hidden">
                                                    <div class="separator--solid"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                </div>
            </section>
        </div>
        <div data-trackable="list:top-stories;listTitle:empty" data-trackable-context-list-type="top-stories"
            data-trackable-context-list-position="9" data-trackable-context-list-siblings="20"
            class="story-group-slice">
            <section class="slice top-stories-slice slice__no-title slice--default">
                <div class="slice__content">
                    <div class="separator--solid"></div>
                    <div class="layout-desktop__grid-container">
                        <?php
                        // $top_stories = $controller->posts(19, 4, array('PostContent'));
                        $top_stories = array_slice($HomeData,13,4);
                        foreach ($top_stories as $key => $value):
                            $class_name = $key%2==1?'story-group--featured':'';
                        $CategoryName = $categories[$value->CatId]['TermName'];
                        $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                        $slug = base_url($value->PostSlug);
                        $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                        // $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : "<br>" . $post_title;
                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                        $thumb_url = $value->PostThumbUrl;
                        ?>
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span3 layout-desktop__grid--column-start-1 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:management;storyGroup:small"
                                    data-trackable-context-storygroup-size="small"
                                    data-trackable-context-storygroup-title="management"
                                    data-trackable-context-storygroup-position="0"
                                    data-trackable-context-storygroup-siblings="4" class="layout-desktop--full-height">
                                    <div class="story-group <?= $class_name?>">
                                        <div class="grid grid--1-columns grid--fullHeight"
                                            style="grid-template-rows:min-content;-ms-grid-rows:min-content">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-1 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--lead">
                                                    <div data-trackable="story:lead"
                                                        data-trackable-context-story-type="lead"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="1"
                                                        class="grid grid--3-columns grid--s4-spacing grid--fullHeight">
                                                        <div class="grid-item grid-item--span-3">
                                                            <div class="grid grid--1-columns grid--s3-spacing">
                                                                <div
                                                                    class="primary-story__image primary-story__image--1-cols">
                                                                    <a data-trackable="image-link"
                                                                        data-trackable-context-story-link="image-link"
                                                                        href="<?= $slug?>" class="link" target="_self"
                                                                        tabindex="-1" aria-hidden="true">

                                                                        <img data-src="<?= $thumb_url?>"
                                                                            alt="Negotiation in the age of the dual-career couple"
                                                                            class="image image--width-280 lazy">
                                                                    </a>
                                                                </div>
                                                                <div class="primary-story__teaser">
                                                                    <div class="story-group__title"><a
                                                                            data-trackable="story-group-title-link"
                                                                            data-trackable-context-story-link="story-group-title-link"
                                                                            href="<?= $CategorySlug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-claret text-sans--scale-0 text--weight-600"
                                                                                id=""><?= $CategoryName?></span></a>
                                                                    </div>
                                                                    <div class="headline js-teaser-headline headline--scale-3 headline--color-black"
                                                                        data-content-id="161e9593-02cd-438d-a471-afea569c1f47">
                                                                        <a data-trackable="heading-link"
                                                                            data-trackable-context-story-link="heading-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                placeholder="headlineIndicator"
                                                                                class="headline-indicator"><span
                                                                                    class="icon icon--opinion icon--scale-3">
                                                                                    <span
                                                                                        class="o-normalise-visually-hidden">opinion
                                                                                        content.&nbsp;</span></span></span><span
                                                                                class="text text--color-black text-display--scale-3 text--weight-400"
                                                                                id=""><?= $post_title?></span></a>
                                                                    </div>
                                                                    <p class="standfirst"><a
                                                                            data-trackable="standfirst-link"
                                                                            data-trackable-context-story-link="standfirst-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black-60 text-sans--scale-0 text--style--no-active-state"
                                                                                id=""><?= $content?></span></a></p>
                                                                </div>
                                                                <div
                                                                    class="grid-item grid-item--span-1 grid-item--align-self-end">
                                                                    <div class="metadata metadata__timestamp">
                                                                        <div class="timestamp"><time
                                                                                class="timestamp-date o-date"
                                                                                data-o-component="o-date"
                                                                                data-o-date-format="time-ago-limit-4-hours"
                                                                                datetime="2023-05-08T03:00:23+0000">3
                                                                                hours ago</time></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="story-group__separator story-group__separator--hidden">
                                                    <div class="separator--solid"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                </div>
            </section>
        </div>
        <div data-trackable="list:top-stories;listTitle:empty" data-trackable-context-list-type="top-stories"
            data-trackable-context-list-position="9" data-trackable-context-list-siblings="20"
            class="story-group-slice">
            <section class="slice top-stories-slice slice__no-title slice--default">
                <div class="slice__content">
                    <div class="separator--solid"></div>
                    <div class="layout-desktop__grid-container">
                        <?php
                        // $top_stories = $controller->posts(23, 4, array('PostContent'));
                        $top_stories = array_slice($HomeData,17,4);
                        foreach ($top_stories as $key => $value):
                            $class_name = $key%2==0?'story-group--featured':'';
                        $CategoryName = $categories[$value->CatId]['TermName'];
                        $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                        $slug = base_url($value->PostSlug);
                        $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                        // $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : "<br>" . $post_title;
                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                        $thumb_url = $value->PostThumbUrl;
                        ?>
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span3 layout-desktop__grid--column-start-1 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:management;storyGroup:small"
                                    data-trackable-context-storygroup-size="small"
                                    data-trackable-context-storygroup-title="management"
                                    data-trackable-context-storygroup-position="0"
                                    data-trackable-context-storygroup-siblings="4" class="layout-desktop--full-height">
                                    <div class="story-group <?= $class_name?>">
                                        <div class="grid grid--1-columns grid--fullHeight"
                                            style="grid-template-rows:min-content;-ms-grid-rows:min-content">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-1 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--lead">
                                                    <div data-trackable="story:lead"
                                                        data-trackable-context-story-type="lead"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="1"
                                                        class="grid grid--3-columns grid--s4-spacing grid--fullHeight">
                                                        <div class="grid-item grid-item--span-3">
                                                            <div class="grid grid--1-columns grid--s3-spacing">
                                                                <div
                                                                    class="primary-story__image primary-story__image--1-cols">
                                                                    <a data-trackable="image-link"
                                                                        data-trackable-context-story-link="image-link"
                                                                        href="<?= $slug?>" class="link" target="_self"
                                                                        tabindex="-1" aria-hidden="true">
                                                                        <img src="<?= $thumb_url?>"
                                                                            alt="Negotiation in the age of the dual-career couple"
                                                                            class="image image--width-280 lazy">
                                                                    </a>
                                                                </div>
                                                                <div class="primary-story__teaser">
                                                                    <div class="story-group__title"><a
                                                                            data-trackable="story-group-title-link"
                                                                            data-trackable-context-story-link="story-group-title-link"
                                                                            href=<?= $CategorySlug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-claret text-sans--scale-0 text--weight-600"
                                                                                id=""><?= $CategoryName?></span></a>
                                                                    </div>
                                                                    <div class="headline js-teaser-headline headline--scale-3 headline--color-black"
                                                                        data-content-id="161e9593-02cd-438d-a471-afea569c1f47">
                                                                        <a data-trackable="heading-link"
                                                                            data-trackable-context-story-link="heading-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                placeholder="headlineIndicator"
                                                                                class="headline-indicator"><span
                                                                                    class="icon icon--opinion icon--scale-3">
                                                                                    <span
                                                                                        class="o-normalise-visually-hidden">opinion
                                                                                        content.&nbsp;</span></span></span><span
                                                                                class="text text--color-black text-display--scale-3 text--weight-400"
                                                                                id=""><?= $post_title?></span></a>
                                                                    </div>
                                                                    <p class="standfirst"><a
                                                                            data-trackable="standfirst-link"
                                                                            data-trackable-context-story-link="standfirst-link"
                                                                            href="<?= $slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black-60 text-sans--scale-0 text--style--no-active-state"
                                                                                id=""><?= $content?></span></a></p>
                                                                </div>
                                                                <!-- <div
                                                                    class="grid-item grid-item--span-1 grid-item--align-self-end">
                                                                    <div class="metadata metadata__timestamp">
                                                                        <div class="timestamp"><time
                                                                                class="timestamp-date o-date"
                                                                                data-o-component="o-date"
                                                                                data-o-date-format="time-ago-limit-4-hours"
                                                                                datetime="2023-05-08T03:00:23+0000">3
                                                                                hours ago</time></div>
                                                                    </div>
                                                                </div> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="story-group__separator story-group__separator--hidden">
                                                    <div class="separator--solid"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                </div>
            </section>
        </div>
        <!-- end news -->
        <section class="slice advert-slice slice__no-title">
            <div class="slice__content">
                <div class="layout-tablet__grid-container">
                    <div
                        class="layout-tablet__grid layout-tablet__grid--span12 layout-tablet__grid--column-start-1 layout-tablet__grid--row-start-1">
                        <div class="layout__grid-content">
                            <div class="o-ads o-ads--center o-ads--transition o-ads--center" data-o-ads-init="true"
                                data-o-ads-name="mid1" data-o-ads-targeting="pos=mid1"
                                data-o-ads-formats="MediumRectangle"
                                data-o-ads-formats-default="MediumRectangle,OneByOne,Responsive"
                                data-o-ads-formats-small="MediumRectangle,OneByOne,Responsive"
                                data-o-ads-formats-medium="Leaderboard,OneByOne,Responsive"
                                data-o-ads-formats-large="SuperLeaderboard,Leaderboard,Billboard,OneByOne,Responsive"
                                data-o-ads-formats-extra="SuperLeaderboard,Leaderboard,Billboard,OneByOne,Responsive">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div data-trackable="list:technology" data-trackable-context-list-type="technology"
            data-trackable-context-list-position="19" data-trackable-context-list-siblings="20"
            class="story-group-slice">
            <section class="slice slice--default">
                <div class="slice__content">
                    <div class="separator--dotted"></div>
                    <header id="technology" class="slice-heading">
                        <h2 class="slice-heading__title"><a data-trackable="link"
                                data-trackable-context-story-link="link" href="/technology" class="link" target="_self"
                                aria-hidden="false"><span class="text text--color-black-80 text-sans--scale-0"
                                    id="">Highlights</span></a>
                        </h2>
                    </header>
                    <div class="layout-desktop__grid-container">
                        <div
                            class="layout-desktop__grid layout-desktop__grid--span12 layout-desktop__grid--column-start-1 layout-desktop__grid--row-start-1 layout-desktop__grid--with-border layout--default">
                            <div class="layout__grid-content">
                                <div data-trackable="storyGroupTitle:storygroup;storyGroup:large"
                                    data-trackable-context-storygroup-size="large"
                                    data-trackable-context-storygroup-title="storygroup"
                                    data-trackable-context-storygroup-position="0"
                                    data-trackable-context-storygroup-siblings="2" class="layout-desktop--full-height">
                                    <div class="story-group">
                                        <div class="grid grid--3-columns grid--fullHeight"
                                            style="grid-template-rows:min-content;-ms-grid-rows:min-content">
                                            <div
                                                class="story-group__article-wrapper story-group--row-start-1 story-group--column-start-1 story-group--full-width-3 story-group--end-of-row">
                                                <div class="story-group__article story-group__article--lead">
                                                    <div data-trackable="story:lead"
                                                        data-trackable-context-story-type="lead"
                                                        data-trackable-context-story-position="0"
                                                        data-trackable-context-story-siblings="7"
                                                        class="grid grid--3-columns grid--s4-spacing grid--fullHeight">
                                                        <?php
                                                        // $hightlights = $controller->posts(23, 9, array('PostContent'));
                                                        $hightlights = array_slice($HomeData,21,9);
                                                        foreach ($hightlights as $key => $value):
                                                            $class_name = $key%2==0?'story-group--featured':'';
                                                        $CategoryName = $categories[$value->CatId]['TermName'];
                                                        $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
                                                        $slug = base_url($value->PostSlug);
                                                        $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
                                                        // $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : "<br>" . $post_title;
                                                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                                                        $thumb_url = $value->PostThumbUrl;
                                                        ?>
                                                        <div class="grid-item grid-item--span-1">
                                                            <div class="grid grid--1-columns grid--s3-spacing">
                                                                <div class="primary-story__teaser">
                                                                    <a class="link" href="<?=$slug?>">
                                                                        <img data-src="<?= $thumb_url?>"
                                                                            alt="EU steps up efforts to clamp down on Russia sanctions evasion"
                                                                            class="image image--width-580 lazy">

                                                                    </a>

                                                                    <div class="headline js-teaser-headline headline--scale-4 headline--color-black"
                                                                        data-content-id="6df6495f-189d-41d9-aa70-c1364386dfce">
                                                                        <a data-trackable="heading-link"
                                                                            data-trackable-context-story-link="heading-link"
                                                                            href="<?=$slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                placeholder="headlineIndicator"
                                                                                class="headline-indicator"><span
                                                                                    class="text text--color-black text-display--scale-4 text--weight-600"
                                                                                    id="">
                                                                                </span></span><span
                                                                                class="text text--color-black text-display--scale-4 text--weight-500"
                                                                                id=""><?= $post_title?></span></a>
                                                                    </div>
                                                                    <p class="standfirst"><a
                                                                            data-trackable="standfirst-link"
                                                                            data-trackable-context-story-link="standfirst-link"
                                                                            href="<?=$slug?>" class="link"
                                                                            target="_self" aria-hidden="false"><span
                                                                                class="text text--color-black-60 text-sans--scale-0 text--style--no-active-state"
                                                                                id=""><?= $content?></span></a></p>
                                                                </div>
                                                                <!--  <div
                                                                    class="grid-item grid-item--span-1 grid-item--align-self-end">
                                                                    <div class="metadata metadata__timestamp">
                                                                        <div class="timestamp"><time
                                                                                class="timestamp-date o-date"
                                                                                data-o-component="o-date"
                                                                                data-o-date-format="time-ago-limit-4-hours"
                                                                                datetime="2023-05-08T05:00:23+0000">1
                                                                                hour ago</time></div>
                                                                    </div>
                                                                </div> -->
                                                                <div class="story-group__separator">
                                                                    <div class="separator--solid"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php endforeach?>

                                                    </div>
                                                </div>
                                                <div class="story-group__separator story-group__separator--hidden">
                                                    <div class="separator--solid"></div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
            </section>
        </div>

    </main>

</div>