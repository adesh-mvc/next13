<?php if (trim($settings->SidebarAds)): ?>
<aside class="wrapper__list__article">
    <?=$settings->SidebarAds;?>
</aside>
<?php endif;?>



<div class="sidebar-sticky" style="">
    <div class="inner-wrapper-sticky" style="position: relative; transform: translate3d(0px, 0px, 0px);">
        <aside class="wrapper__list__article ">
            <h4 class="border_section">recent post</h4>
            <div class="wrapper__list__article-small">
                <?php
$sidebar = $controller->posts(0, 9, array('PostContent'));
$row = 1;
foreach ($sidebar as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 45 ? substr($post_title, 0, 45) . '...' : $post_title;
    $thumb_url = $value->PostThumbUrl;
    $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 40));
    if ($row < 3):
    ?>
                <div class="mb-3 bg-light">
                    <!-- Post Article -->
                    <div class="card__post card__post-list">
                        <div class="image-sm">
                            <a href="<?=$slug?>">
                                <img src="<?=$thumb_url?>" class="img-fluid" alt="<?=$title?>">
                            </a>
                        </div>


                        <div class="card__post__body ">
                            <div class="card__post__content">

                                <div class="card__post__author-info mb-2">
                                    <ul class="list-inline">

                                        <li class="list-inline-item">
                                            <span class="text-dark text-capitalize">
                                                <?=date('F d, Y', strtotime($value->Date));?>
                                            </span>
                                        </li>

                                    </ul>
                                </div>
                                <div class="card__post__title">
                                    <h6>
                                        <a href="<?=$slug?>">
                                            <?=$title?>
                                        </a>
                                    </h6>


                                </div>

                            </div>


                        </div>
                    </div>
                </div>
                <?php else:$row = 0;?>

                <!-- Post Article -->
                <div class="article__entry bg-light">
                    <div class="article__image">
                        <a href="<?=$slug?>">
                            <img data-src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid lazy">
                        </a>
                    </div>
                    <div class="article__content">
                        <div class="article__category">
                            travel
                        </div>
                        <ul class="list-inline">

                            <li class="list-inline-item">
                                <span class="text-dark text-capitalize">
                                    <?=date('F d, Y', strtotime($value->Date));?>
                                </span>
                            </li>

                        </ul>
                        <h5>
                            <a href="<?=$slug?>">
                                <?=$title?>
                            </a>
                        </h5>
                        <p>
                            <?=$content?>
                        </p>
                        <a href="<?=$slug?>" class="btn btn-outline-primary mb-4 text-capitalize"> read more</a>
                    </div>
                </div>
                <?php endif?>
                <?php $row++;endforeach?>
            </div>
        </aside>



    </div>
</div>