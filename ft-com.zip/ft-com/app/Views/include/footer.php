 <div class="n-layout__row n-layout__row--footer">

     <?php if ($settings->FooterAds): ?>
     <div class="n-layout__footer-before">
         <!--AD Body Start-->
         <?php if (!empty($_GET['static'])) {?>
         <div id="advertize_content2"> Advertize Content Two
             <?=$settings->FooterAds;?>
         </div>
         <?php } else {?>
         <?=$settings->FooterAds;?>
         <?php }?>
         <!--AD Body End-->
     </div>
     <?php endif?>

     <footer id="site-footer" class="o-footer o-footer--theme-dark" data-o-component="o-footer">
         <div class="o-footer__container">
             <div class="o-footer__row">
                 <h2 class="o-normalise-visually-hidden">Useful links</h2>
                 <nav class="o-footer__matrix" role="navigation" aria-label="Useful links">
                     <div class="o-footer__matrix-group o-footer__matrix-group--1">
                         <h3 class="o-footer__matrix-title" aria-controls="o-footer-section-0">About</h3>
                         <div class="o-footer__matrix-content" id="o-footer-section-0">
                             <div class="o-footer__matrix-column">
                                 <?=$settings->footerAbout;?>
                             </div>
                         </div>
                     </div>
                     <div class="o-footer__matrix-group o-footer__matrix-group--1">
                         <h3 class="o-footer__matrix-title" aria-controls="o-footer-section-1">Pages</h3>
                         <div class="o-footer__matrix-content" id="o-footer-section-1">
                             <div class="o-footer__matrix-column">


                                 <?php foreach ($pages as $key => $value): ?>
                                 <a class="o-footer__matrix-link" href="<?=base_url($value->PageSlug);?>"
                                     data-trackable="Terms &amp; Conditions"><span
                                         class="o-footer__matrix-link__copy"><?=$value->PageTitle;?></span></a>
                                 <?php endforeach;?>

                             </div>
                         </div>
                     </div>
                     <div class="o-footer__matrix-group o-footer__matrix-group--1">
                         <h3 class="o-footer__matrix-title" aria-controls="o-footer-section-2">Services</h3>
                         <div class="o-footer__matrix-content" id="o-footer-section-2">
                             <div class="o-footer__matrix-column"><a class="o-footer__matrix-link" href="/securedrop"
                                     data-trackable="Share News Tips Securely" data-o-tracking-do-not-track="true"><span
                                         class="o-footer__matrix-link__copy">Share News Tips
                                         Securely</span></a><a class="o-footer__matrix-link"
                                     href="http://www.ft.com/products" data-trackable="Individual Subscriptions"><span
                                         class="o-footer__matrix-link__copy">Individual
                                         Subscriptions</span></a><a class="o-footer__matrix-link"
                                     href="https://enterprise.ft.com/en-gb/services/group-subscriptions/group-contact-us/?segmentId=383c7f63-abf4-b62d-cb33-4c278e6fdf61&amp;cpccampaign=B2B_link_ft.com_footer"
                                     data-trackable="Group Subscriptions"><span
                                         class="o-footer__matrix-link__copy">Group
                                         Subscriptions</span></a><a class="o-footer__matrix-link"
                                     href="https://enterprise.ft.com/en-gb/services/republishing/"
                                     data-trackable="Republishing"><span
                                         class="o-footer__matrix-link__copy">Republishing</span></a><a
                                     class="o-footer__matrix-link" href="https://www.exec-appointments.com/"
                                     data-trackable="Executive Job Search"><span
                                         class="o-footer__matrix-link__copy">Executive Job Search</span></a><a
                                     class="o-footer__matrix-link" href="http://fttoolkit.co.uk/"
                                     data-trackable="Advertise with the FT"><span
                                         class="o-footer__matrix-link__copy">Advertise with
                                         the FT</span></a><a class="o-footer__matrix-link"
                                     href="https://twitter.com/financialtimes"
                                     data-trackable="Follow the FT on Twitter"><span
                                         class="o-footer__matrix-link__copy">Follow the FT
                                         on Twitter</span></a><a class="o-footer__matrix-link"
                                     href="https://channels.ft.com/" data-trackable="FT Channels"><span
                                         class="o-footer__matrix-link__copy">FT Channels</span></a><a
                                     class="o-footer__matrix-link"
                                     href="https://enterprise.ft.com/en-gb/services/group-subscriptions/secondary-education/"
                                     data-trackable="Secondary Schools"><span
                                         class="o-footer__matrix-link__copy">Secondary
                                         Schools</span></a></div>
                         </div>
                     </div>
                     <div class="o-footer__matrix-group o-footer__matrix-group--1">
                         <h3 class="o-footer__matrix-title" aria-controls="o-footer-section-3">Tools</h3>
                         <div class="o-footer__matrix-content" id="o-footer-section-3">
                             <div class="o-footer__matrix-column"><a class="o-footer__matrix-link"
                                     href="https://markets.ft.com/data/portfolio/dashboard"
                                     data-trackable="Portfolio"><span
                                         class="o-footer__matrix-link__copy">Portfolio</span></a><a
                                     class="o-footer__matrix-link" href="https://www.ft.com/todaysnewspaper"
                                     data-trackable="Today's Newspaper (ePaper)"><span
                                         class="o-footer__matrix-link__copy">Today's Newspaper
                                         (ePaper)</span></a><a class="o-footer__matrix-link"
                                     href="http://markets.ft.com/data/alerts/" data-trackable="Alerts Hub"><span
                                         class="o-footer__matrix-link__copy">Alerts Hub</span></a><a
                                     class="o-footer__matrix-link" href="https://rankings.ft.com/"
                                     data-trackable="Business School Rankings"><span
                                         class="o-footer__matrix-link__copy">Business
                                         School Rankings</span></a><a class="o-footer__matrix-link"
                                     href="https://kat.ft.com/" data-trackable="Enterprise Tools"><span
                                         class="o-footer__matrix-link__copy">Enterprise
                                         Tools</span></a><a class="o-footer__matrix-link" href="/news-feed"
                                     data-trackable="News feed"><span class="o-footer__matrix-link__copy">News
                                         feed</span></a><a class="o-footer__matrix-link" href="/newsletters"
                                     data-trackable="Newsletters"><span
                                         class="o-footer__matrix-link__copy">Newsletters</span></a><a
                                     class="o-footer__matrix-link"
                                     href="https://markets.ft.com/research/Markets/Currencies?segid=70113"
                                     data-trackable="Currency Converter"><span
                                         class="o-footer__matrix-link__copy">Currency
                                         Converter</span></a></div>
                         </div>
                     </div>
                     <div class="o-footer__matrix-group o-footer__matrix-group--1">
                         <h3 class="o-footer__matrix-title" aria-controls="o-footer-section-4">Community &amp;
                             Events</h3>
                         <div class="o-footer__matrix-content" id="o-footer-section-4">
                             <div class="o-footer__matrix-column"><a class="o-footer__matrix-link"
                                     href="https://www.ft.com/tour/community" data-trackable="FT Community"><span
                                         class="o-footer__matrix-link__copy">FT Community</span></a><a
                                     class="o-footer__matrix-link" href="http://live.ft.com/"
                                     data-trackable="FT Live Events"><span class="o-footer__matrix-link__copy">FT
                                         Live Events</span></a><a class="o-footer__matrix-link"
                                     href="https://forums.ft.com/" data-trackable="FT Forums"><span
                                         class="o-footer__matrix-link__copy">FT Forums</span></a><a
                                     class="o-footer__matrix-link"
                                     href="https://enterprise.ft.com/board-director-membership"
                                     data-trackable="FT Board Director"><span class="o-footer__matrix-link__copy">FT
                                         Board
                                         Director</span></a><a class="o-footer__matrix-link" href="https://bdp.ft.com/"
                                     data-trackable="Board Director Programme"><span
                                         class="o-footer__matrix-link__copy">Board Director
                                         Programme</span></a></div>
                         </div>
                     </div>
                     <div class="o-footer__matrix-group o-footer__matrix-group--1">
                         <h3 class="o-footer__matrix-title o-footer__matrix-title--link"><a
                                 class="o-footer__matrix-link o-footer__matrix-link--more" id="o-footer-5"
                                 href="https://ft.com/more-from-ft-group"><span class="o-footer__matrix-link__copy">More
                                     from the FT
                                     Group</span></a></h3>
                     </div>
                 </nav>
             </div>
             <div class="o-footer__copyright"><small>© Copyright <?=date('Y');?> <?=$settings->CopyRight;?>
                     All Rights Reserved.</small>
             </div>
         </div>
         <div class="o-footer__brand">
             <div class="o-footer__container">
                 <div class="o-footer__brand-logo"></div>
             </div>
         </div>
     </footer>
     <div class="n-layout__footer-after">
         <script
             data-pixel-src="https://spoor-api.ft.com/px.gif?data=%7B%22category%22%3A%22page%22%2C%22action%22%3A%22view%22%2C%22system%22%3A%7B%22source%22%3A%22non-ctm%22%7D%2C%22context%22%3A%7B%22name%22%3A%22home-page%22%2C%22product%22%3A%22next%22%2C%22data%22%3A%7B%22source%22%3A%22%5BSOURCE%5D%22%7D%7D%7D">
         (function coreExperience() {
             if (/\bcore\b/.test(document.documentElement.className)) {
                 var currentScript = document.scripts[document.scripts.length - 1];
                 var img = new Image();
                 img.src = currentScript.getAttribute('data-pixel-src');
             }
         })();
         </script><noscript><img
                 src="https://spoor-api.ft.com/px.gif?data=%7B%22category%22%3A%22page%22%2C%22action%22%3A%22view%22%2C%22system%22%3A%7B%22source%22%3A%22non-ctm%22%7D%2C%22context%22%3A%7B%22name%22%3A%22home-page%22%2C%22product%22%3A%22next%22%2C%22data%22%3A%7B%22source%22%3A%22%5BSOURCE%5D%22%7D%7D%7D" /></noscript>
     </div>
 </div>
 <div class="o-header__drawer" id="o-header-drawer" role="modal" aria-label="Drawer menu" aria-modal="true"
     data-o-header-drawer="true" data-o-header-drawer--no-js="true" data-trackable="drawer"
     data-trackable-terminate="true">
     <div class="o-header__drawer-inner">
         <div class="o-header__drawer-tools"><button type="button" class="o-header__drawer-tools-close"
                 title="Close side navigation menu" aria-controls="o-header-drawer" data-trackable="close"><span
                     class="o-header__visually-hidden">Close side navigation menu</span></button><a
                 class="o-header__drawer-tools-logo" href="<?= site_url()?>" data-trackable="logo">
                 <?php if ($settings->SiteLogo): ?>

                 <img class="jl_logo_n" src="<?=$settings->SiteLogo;?>" alt="<?=$settings->SiteTitle;?>">


                 <?php else: ?>
                 <span class="o-header__visually-hidden"><?=$settings->SiteTitle;?></span>
                 <?php endif;?>
             </a>

         </div>

         <div class="o-header__drawer-search">
             <form class="o-header__drawer-search-form" action="<?=base_url('search')?>" role="search"
                 aria-label="Site search" data-n-topic-search="true" data-n-topic-search-categories="concepts,equities"
                 data-n-topic-search-view-all="true"><label class="o-header__visually-hidden"
                     for="o-header-drawer-search-term">Search the <abbr title="Financial Times">...</abbr></label><input
                     type="text" class="o-header__drawer-search-term" id="o-header-drawer-search-term" name="q"
                     autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"
                     placeholder="Search ..." data-trackable="search-term" data-n-topic-search-input="true"><button
                     class="o-header__drawer-search-submit" type="submit" data-trackable="search-submit"><span
                         class="o-header__visually-hidden">Search</span></button></form>
         </div>
         <!--  <nav class="o-header__drawer-menu" aria-label="Edition switcher">
             <ul class="o-header__drawer-menu-list">
                 <li class="o-header__drawer-menu-item" data-trackable="edition-switcher"><a
                         class="o-header__drawer-menu-link" href="/?edition=uk" data-trackable="uk">Switch to UK
                         Edition</a></li>
             </ul>
         </nav> -->
         <nav class="o-header__drawer-menu o-header__drawer-menu--primary">

             <ul aria-labelledby="top-sections" class="o-header__drawer-menu-list">
                 <li class="o-header__drawer-menu-item"><a
                         class="o-header__drawer-menu-link o-header__drawer-menu-link--selected" href="<?= site_url()?>"
                         data-trackable="Home" aria-label="Home, current page" aria-current="page">Home</a></li>
                 <?php foreach ($categories as $key => $value): ?>

                 <li class="o-header__drawer-menu-item"><a class="o-header__drawer-menu-link "
                         href="<?=base_url('category/' . $value['TermSlug'])?>"><?=$value['TermName']?></a></li>
                 <?php endforeach;?>



             </ul>

         </nav>
         <!--   <nav class="o-header__drawer-menu o-header__drawer-menu--user" data-trackable="user-nav">
                    <ul class="o-header__drawer-menu-list">
                        <li class="o-header__drawer-menu-item"><a class="o-header__drawer-menu-link"
                                href="http://help.ft.com" data-trackable="Help Centre">Help Centre</a></li>
                        <li class="o-header__drawer-menu-item"><a class="o-header__drawer-menu-link"
                                href="/products?segmentId=d290332b-e8e8-d29b-2ff4-2019b13f008a"
                                data-trackable="Subscribe">Subscribe</a>
                        </li>
                        <li class="o-header__drawer-menu-item"><a class="o-header__drawer-menu-link"
                                href="/login?location=/" data-trackable="Sign In">Sign In</a></li>
                    </ul>
                </nav> -->
     </div>
 </div>
 </div>
 <script src="<?=base_url('assets')?>/js/lazyload.min.js"></script>
 <script src="<?=base_url('assets')?>/js/lazyinit.js"></script>
 </body>

 </html>