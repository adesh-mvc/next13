<?php $category_name = $categories[$CatId]['TermName'];
$category_slug = base_url('category/' . $categories[$CatId]['TermSlug']);
?>
<div class="n-layout__row n-layout__row--content">
    <div>



        <div role="navigation" aria-label="category navigation" class="sub-header" data-trackable="sub-header">



            <div class="o-grid-container">

                <div class="o-grid-row">

                    <div class="sub-header__section sub-header__section--title " data-o-grid-colspan="12 M8 XL9">


                        <h1 class="o-teaser-collection__heading o-teaser-collection__heading--full-width">
                            <?= $category_name?>
                        </h1>
                        <h2 class="o-teaser-collection__heading o-teaser-collection__heading--full-width"
                            aria-label="Latest News in Technology">

                        </h2>





                    </div>
                </div>
            </div>
        </div>



        <div role="main" id="site-content" data-concept-id="e58e66fe-7cc6-4382-b781-1161bae8b905">

            <div class="o-grid-container">
                <div class="o-grid-row">
                    <div data-o-grid-colspan="12">
                        <div class="css-grid__container">

                            <!-- top -->
                            <div class="css-grid__item-top">

                                <?php $IsWhere = array('CatId' => $CatId);
                                    $categories_array = $controller->posts(0, $show_limit, array('PostContent'), $IsWhere);
                                    if (is_countable($categories_array) && count($categories_array)):
                                    ?>
                                <div class="o-grid-row" id="content_masonry">
                                    <?php

                                    foreach ($categories_array as $key => $value):

                                        $title = strlen($value->PostTitle) > 40 ? substr($value->PostTitle, 0, 40) . "..." : $value->PostTitle;
                                        $slug = base_url($value->PostSlug);

                                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                                        $thumb_url = $value->PostThumbUrl;

                                        ?>


                                    <div class=" js-track-scroll-event" data-o-grid-colspan="12 L6">
                                        <div class="o-teaser-collection" data-trackable="top-stories-column-one">


                                            <div class="o-teaser o-teaser--article o-teaser--large o-teaser--has-image js-teaser"
                                                data-id="9277dc72-0b64-47ca-a62f-a90f9a5086d8">
                                                <div class="o-teaser__content">

                                                    <div class="o-teaser__heading"><a href="<?= $slug?>"
                                                            data-trackable="heading-link"
                                                            class="js-teaser-heading-link"><?= $title?> </a></div>
                                                    <p class="o-teaser__standfirst"><a href="<?= $slug?>"
                                                            data-trackable="standfirst-link" tabindex="-1"
                                                            class="js-teaser-standfirst-link"><?= $content?></a>


                                                        <span class="o-teaser__meta"><a class="o-teaser__tag"
                                                                data-trackable="teaser-tag" href="<?= $slug?>">Read
                                                                More...</a></span>
                                                    </p>

                                                </div>
                                                <div class="o-teaser__image-container js-teaser-image-container">
                                                    <a href="<?= $slug?>" data-trackable="image-link" tabindex="-1"
                                                        aria-hidden="true">
                                                        <div class="o-teaser__image-placeholder"
                                                            style="padding-bottom:56.2471%;"><img
                                                                class="o-teaser__image" src="<?= $thumb_url?>"
                                                                alt="<?= $title?>">
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                    <?php endforeach?>

                                </div>

                                <div class="o-teaser-community__button-wrapper">
                                    <a class="aside--community__community-button" id="loadItems"
                                        href="javascript:void(0)">load
                                        more</a>
                                </div>

                                <?php else: ?>
                                <nav class="jellywp_pagination">
                                    <div class="page-numbers">
                                        <span aria-current="page" class="page-numbers current">No Post Found</span>

                                    </div>
                                </nav>
                                <?php endif;?>
                            </div>

                            <!-- right sidebar -->
                            <div class="css-grid__sidebar">
                                <?= $this->include('include/sidebar')?>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<script>
const loadButton = document.getElementById("loadItems");
if (document.contains(loadButton)) {
    //alert();
}
const category = "<?=$category_slug;?>";

var page = "<?php echo $page; ?>";
loadButton.addEventListener("click", function(e) {
    e.preventDefault();
    page++;
    console.log(page);
    xhrRequest(page);
});

function xhrRequest(page) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", `<?=site_url('category/add/')?>${page}/${<?=$CatId?>}`, true);
    xhr.onload = function() {
        if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {
                // console.log(xhr.responseText);
                if (xhr.responseText != "finished") {
                    //  console.log(xhr.response)
                    document
                        .getElementById("content_masonry")
                        .insertAdjacentHTML("beforeend", xhr.response);
                    if (page > 2)
                        history.pushState("/home", "Title", `${category}/page/${page}`);
                    else history.pushState("/home", "Title", `${category}/page/${page}`);
                } else {
                    // loadButton.disabled = true;
                    loadButton.style.opacity = .8;
                    loadButton.style.pointerEvents = 'none';
                    loadButton.parentNode.classList.add('active');
                    console.log(loadButton.parentNode)
                    loadButton.innerHTML = "You have reached the end.";
                }
            }
        }
    };
    xhr.send();
}
</script>