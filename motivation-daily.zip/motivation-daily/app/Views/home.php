<!-- Tranding news  carousel-->
<section class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wrapp__list__article-responsive wrapp__list__article-responsive-carousel">

                    <?php foreach (array_slice($featured, 0, 6) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 45 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;
    $thumb_url = $value->PostThumbUrl;?>

                    <div class="item">
                        <!-- Post Article -->
                        <div class="card__post card__post-list">
                            <div class="image-sm">
                                <a href="<?=$slug?>">
                                    <img data-src="<?=$thumb_url?>" class="img-fluid lazy" alt="<?=$title?>">
                                </a>
                            </div>


                            <div class="card__post__body ">
                                <div class="card__post__content">

                                    <div class="card__post__author-info mb-2">
                                        <ul class="list-inline">

                                            <li class="list-inline-item">
                                                <span class="text-dark text-capitalize">
                                                    <?=date('F d, Y', strtotime($value->Date))?>
                                                </span>
                                            </li>

                                        </ul>
                                    </div>
                                    <div class="card__post__title">
                                        <h6>
                                            <a href="<?=$slug?>">
                                                <?=$title?>
                                            </a>
                                        </h6>


                                    </div>

                                </div>


                            </div>
                        </div>
                    </div>
                    <?php endforeach?>




                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Tranding news carousel -->
<?php if ($settings->HeaderAds): ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">


            <!--AD Body Start-->
            <?php if (!empty($_GET['static'])) {?>
            <div id="advertize_content"> Advertize Content One
                <?=$settings->HeaderAds;?>
            </div>
            <?php } else {?>
            <?=$settings->HeaderAds;?>
            <?php }?>

        </div>
    </div>
</div>

<?php endif;?>

<!-- Popular news -->
<section>
    <!-- Popular news  header-->
    <div class="popular__news-header">
        <div class="container">
            <div class="row no-gutters">
                <div class="col-md-8 ">
                    <div class="card__post-carousel">
                        <?php foreach (array_slice($featured, 6, 3) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 45 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;
    $thumb_url = $value->PostThumbUrl;?>
                        <div class="item">
                            <!-- Post Article -->
                            <div class="card__post">
                                <div class="card__post__body">
                                    <a href="<?=$slug?>">
                                        <img data-src="<?=$thumb_url?>" class="img-fluid lazy" alt="<?=$title?>">
                                    </a>
                                    <div class="card__post__content bg__post-cover">
                                        <div class="card__post__category">
                                            <?=$CategoryName?>
                                        </div>
                                        <div class="card__post__title">
                                            <h2>
                                                <a href="<?=$slug?>">
                                                    <?=$title?>
                                                </a>
                                            </h2>
                                        </div>
                                        <div class="card__post__author-info">
                                            <ul class="list-inline">

                                                <li class="list-inline-item">
                                                    <span>
                                                        <?=date('F d, Y', strtotime($value->Date))?>
                                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <?php endforeach?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="popular__news-right">
                        <!-- Post Article -->
                        <?php foreach (array_slice($featured, 9, 2) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 45 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;
    $thumb_url = $value->PostThumbUrl;?>
                        <div class="card__post ">
                            <div class="card__post__body card__post__transition">
                                <a href="<?=$slug?>">
                                    <img data-src="<?=$thumb_url?>" class="img-fluid lazy" alt="<?=$title?>">
                                </a>
                                <div class="card__post__content bg__post-cover">
                                    <div class="card__post__category">
                                        <?=$CategoryName?>
                                    </div>
                                    <div class="card__post__title">
                                        <h5>
                                            <a href="<?=$slug?>">
                                                <?=$title?></a>
                                        </h5>
                                    </div>
                                    <div class="card__post__author-info">
                                        <ul class="list-inline">

                                            <li class="list-inline-item">
                                                <span>
                                                    <?=date('F d, Y', strtotime($value->Date))?>
                                                </span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <?php endforeach?>
                        <!-- Post Article -->

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Popular news header-->
    <!-- Popular news carousel -->
    <div class="popular__news-header-carousel">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="top__news__slider">
                        <?php foreach (array_slice($featured, 11) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 45 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;
    $thumb_url = $value->PostThumbUrl;?>
                        <div class="item">
                            <!-- Post Article -->
                            <div class="article__entry">
                                <div class="article__image">
                                    <a href="<?=$slug?>">
                                        <img data-src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid lazy">
                                    </a>
                                </div>
                                <div class="article__content">
                                    <ul class="list-inline">


                                        <li class="list-inline-item">
                                            <span>
                                                <?=date('F d, Y', strtotime($value->Date))?>
                                            </span>
                                        </li>
                                    </ul>
                                    <h5>
                                        <a href="<?=$slug?>">
                                            <?=$title?>
                                        </a>
                                    </h5>
                                </div>
                            </div>
                        </div>
                        <?php endforeach?>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Popular news carousel -->
</section>
<!-- End Popular news -->

<!-- Popular news category -->
<section class="pt-0">
    <div class="popular__section-news">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="wrapper__list__article">
                        <h4 class="border_section">Popular post</h4>
                    </div>
                    <div class="row ">
                        <?php
$popular = $controller->posts(15, 15);
foreach (array_slice($popular, 0, 2) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    ?>
                        <div class="col-sm-12 col-md-6 mb-4">
                            <!-- Post Article -->
                            <div class="card__post ">
                                <div class="card__post__body card__post__transition">
                                    <a href="<?=$slug?>">
                                        <img data-src="<?=$thumb_url?>" class="img-fluid lazy" alt="<?=$title?>">
                                    </a>
                                    <div class="card__post__content bg__post-cover">
                                        <div class="card__post__category">
                                            <?=$CategoryName?>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="<?=$slug?>">

                                                    <?=$title?>.</a>
                                            </h5>
                                        </div>
                                        <div class="card__post__author-info">
                                            <ul class="list-inline">

                                                <li class="list-inline-item">
                                                    <span>
                                                        <?=date('F d, Y', strtotime($value->Date))?>
                                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endforeach?>
                    </div>
                    <div class="row ">
                        <div class="col-sm-12 col-md-6">
                            <div class="wrapp__list__article-responsive">
                                <?php
foreach (array_slice($popular, 2, 2) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    ?>
                                <div class="mb-3">
                                    <!-- Post Article -->
                                    <div class="card__post card__post-list">
                                        <div class="image-sm">
                                            <a href="<?=$slug?>">
                                                <img data-src="<?=$thumb_url?>" class="img-fluid lazy"
                                                    alt="<?=$title?>">
                                            </a>
                                        </div>


                                        <div class="card__post__body ">
                                            <div class="card__post__content">

                                                <div class="card__post__author-info mb-2">
                                                    <ul class="list-inline">

                                                        <li class="list-inline-item">
                                                            <span class="text-dark text-capitalize">
                                                                <?=date('F d, Y', strtotime($value->Date))?>
                                                            </span>
                                                        </li>

                                                    </ul>
                                                </div>
                                                <div class="card__post__title">
                                                    <h6>
                                                        <a href="<?=$slug?>">
                                                            <?=$title?>
                                                        </a>
                                                    </h6>

                                                </div>

                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <?php endforeach?>

                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6 ">
                            <div class="wrapp__list__article-responsive">
                                <?php
foreach (array_slice($popular, 4, 2) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    ?>
                                <div class="mb-3">
                                    <!-- Post Article -->
                                    <div class="card__post card__post-list">
                                        <div class="image-sm">
                                            <a href="<?=$slug?>">
                                                <img data-src="<?=$thumb_url?>" class="img-fluid lazy"
                                                    alt="<?=$title?>">
                                            </a>
                                        </div>


                                        <div class="card__post__body ">
                                            <div class="card__post__content">

                                                <div class="card__post__author-info mb-2">
                                                    <ul class="list-inline">

                                                        <li class="list-inline-item">
                                                            <span class="text-dark text-capitalize">
                                                                <?=date('F d, Y', strtotime($value->Date))?>
                                                            </span>
                                                        </li>

                                                    </ul>
                                                </div>
                                                <div class="card__post__title">
                                                    <h6>
                                                        <a href="<?=$slug?>">
                                                            <?=$title?>
                                                        </a>
                                                    </h6>

                                                </div>

                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <?php endforeach?>

                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-12 col-lg-4">
                    <aside class="wrapper__list__article">
                        <h4 class="border_section">Trending post</h4>
                        <div class="wrapper__list-number">

                            <!-- List Article -->
                            <?php
$k = 1;
foreach (array_slice($popular, 6, 4) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    ?>
                            <div class="card__post__list">
                                <div class="list-number">
                                    <span>
                                        <?=$k;
    $k++;?>
                                    </span>
                                </div>
                                <a href="<?=$CategorySlug?>" class="category">
                                    <?=$CategoryName?> </a>
                                <ul class="list-inline">

                                    <li class="list-inline-item">
                                        <span>
                                            <i class="fa fa-calendar"></i>
                                            <?=date('F d, Y', strtotime($value->Date))?>
                                        </span>

                                    </li>
                                    <li class="list-inline-item">
                                        <h5>
                                            <a href="<?=$slug?>">
                                                <?=$title?>
                                            </a>
                                        </h5>
                                    </li>
                                </ul>
                            </div>
                            <?php endforeach?>
                            <!-- List Article -->

                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>

    <!-- Post news carousel -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <aside class="wrapper__list__article">
                    <h4 class="border_section"></h4>
                </aside>
            </div>
            <div class="col-md-12">

                <div class="article__entry-carousel">
                    <?php
foreach (array_slice($popular, 10) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    ?>
                    <div class="item">
                        <!-- Post Article -->
                        <div class="article__entry">
                            <div class="article__image">
                                <a href="<?=$slug?>">
                                    <img src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid">
                                </a>
                            </div>
                            <div class="article__content">
                                <ul class="list-inline">

                                    <li class="list-inline-item">
                                        <span>
                                            <?=date('F d, Y', strtotime($value->Date))?>
                                        </span>
                                    </li>

                                </ul>
                                <h5>
                                    <a href="<?=$slug?>">
                                        <?=$title?>
                                    </a>
                                </h5>

                            </div>
                        </div>
                    </div>
                    <?php endforeach?>

                </div>
            </div>
        </div>
    </div>
    <!-- End Popular news category -->




</section>





<div class="mt-4">
    <div class="container">
        <div class="row">
            <div class="col-md-8 bg-light">
                <aside class="wrapper__list__article mb-0">
                    <h4 class="border_section">Featured</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <?php
$featured_2 = $controller->posts(30, 6);
foreach (array_slice($featured_2, 0, 3) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    ?>
                            <div class="mb-4">
                                <!-- Post Article -->
                                <div class="article__entry">
                                    <div class="article__image">
                                        <a href="<?=$slug?>">
                                            <img data-src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid lazy">
                                        </a>
                                    </div>
                                    <div class="article__content">
                                        <ul class="list-inline">

                                            <li class="list-inline-item">
                                                <span>
                                                    <?=date('F d, Y', strtotime($value->Date))?>
                                                </span>
                                            </li>

                                        </ul>
                                        <h5>
                                            <a href="<?=$slug?>">
                                                <?=$title?>
                                            </a>
                                        </h5>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach?>
                        </div>
                        <div class="col-md-6">
                            <?php

foreach (array_slice($featured_2, 3) as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    ?>
                            <div class="mb-4">
                                <!-- Post Article -->
                                <div class="article__entry">
                                    <div class="article__image">
                                        <a href="<?=$slug?>">
                                            <img data-src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid lazy">
                                        </a>
                                    </div>
                                    <div class="article__content">
                                        <ul class="list-inline">

                                            <li class="list-inline-item">
                                                <span>
                                                    <?=date('F d, Y', strtotime($value->Date))?>
                                                </span>
                                            </li>

                                        </ul>
                                        <h5>
                                            <a href="<?=$slug?>">
                                                <?=$title?>
                                            </a>
                                        </h5>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach?>

                        </div>
                    </div>
                </aside>
                <aside class="wrapper__list__article">
                    <h4 class="border_section">Top Stories</h4>

                    <div class="wrapp__list__article-responsive">
                        <!-- Post Article List -->
                        <?php
$topstories = $controller->posts(36, 14, array('PostContent'));
foreach ($topstories as $key => $value):

    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
    ?>
                        <div class="card__post card__post-list card__post__transition mt-30">
                            <div class="row ">
                                <div class="col-md-5">
                                    <div class="card__post__transition">
                                        <a href="<?=$slug?>">
                                            <img data-src="<?=$thumb_url?>" class="img-fluid w-100 lazy"
                                                alt="<?=$title?>">
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-7 my-auto pl-0">
                                    <div class="card__post__body ">
                                        <div class="card__post__content  ">
                                            <div class="card__post__category ">
                                                <?=$CategoryName?>
                                            </div>
                                            <div class="card__post__author-info mb-2">
                                                <ul class="list-inline">

                                                    <li class="list-inline-item">
                                                        <span class="text-dark text-capitalize">
                                                            <?=date('F d, Y', strtotime($value->Date))?>
                                                        </span>
                                                    </li>

                                                </ul>
                                            </div>
                                            <div class="card__post__title">
                                                <h5>
                                                    <a href="<?=$slug?>">
                                                        <?=$title?>
                                                    </a>
                                                </h5>
                                                <p class="d-none d-lg-block d-xl-block mb-0">
                                                    <?=$content?>...
                                                </p>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <?php endforeach?>

                    </div>
                </aside>
            </div>

            <div class="col-md-4 bg-light">
                <div class="sidebar-sticky ">
                    <aside class="wrapper__list__article">
                        <h4 class="border_section">
                            Latest post</h4>
                        <div class="wrapper__list__article-small">

                            <!-- Post Article -->
                            <?php
$latest = $controller->posts(48, 4, array('PostContent'));
foreach ($latest as $key => $value):

    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;
    $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
    ?>
                            <div class="article__entry">
                                <div class="article__image">
                                    <a href="<?=$slug?>">
                                        <img data-src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid lazy">
                                    </a>
                                </div>
                                <div class="article__content">
                                    <div class="article__category">
                                        <?=$CategoryName?> </div>
                                    <ul class="list-inline">

                                        <li class="list-inline-item">
                                            <span class="text-dark text-capitalize">
                                                <?=date('F d, Y', strtotime($value->Date))?>
                                            </span>
                                        </li>

                                    </ul>
                                    <h5>
                                        <a href="<?=$slug?>">
                                            <?=$title?>
                                        </a>
                                    </h5>
                                    <p>
                                        <?=$title?>
                                    </p>
                                    <a href="<?=$slug?>" class="btn btn-outline-primary mb-4 text-capitalize"> read
                                        more</a>
                                </div>
                            </div>
                            <?php endforeach?>


                        </div>
                    </aside>

                </div>
            </div>


            <div class="clearfix"></div>

        </div>
    </div>
</div>