<!DOCTYPE html>
<html lang="">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta charset="utf-8">
    <title>Retnews &#8211; Best news, blog & magazine template </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="icon.png">

    <meta name="theme-color" content="#030303">
    <!-- google fonts -->
    <link
        href="//fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,500;0,700;1,300;1,500&amp;family=Poppins:ital,wght@0,300;0,500;0,700;1,300;1,400&amp;display=swap"
        rel="stylesheet">
    <link href="<?=base_url('assets')?>/css/styles3875.css?1fcca2a2c42e9d47a3eb" rel="stylesheet">
    <link href="<?=base_url('assets')?>/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
    <!-- Header news -->
    <header class="bg-light">


        <!-- Navbar  -->
        <!-- Navbar menu  -->
        <div class="navigation-wrap navigation-shadow bg-white">
            <nav class="navbar navbar-hover navbar-expand-lg navbar-soft">
                <div class="container">
                    <div class="offcanvas-header">
                        <div data-toggle="modal" data-target="#modal_aside_right" class="btn-md">
                            <span class="navbar-toggler-icon"></span>
                        </div>
                    </div>
                    <figure class="mb-0 mx-auto">
                        <a href="<?=base_url()?>">
                            <?php if ($settings->SiteLogo): ?>
                            <img class="img-fluid logo" src="<?=$settings->SiteLogo;?>"
                                alt="<?=$settings->SiteTitle;?>">
                            <?php else: ?>
                            <span><?=$settings->SiteTitle;?></span>
                            <?php endif;?>
                        </a>
                    </figure>
                    <div class="collapse navbar-collapse justify-content-between" id="main_nav99">
                        <ul class="navbar-nav ml-auto ">
                            <li class="nav-item">
                                <a class="nav-link active" href="<?=base_url()?>"> Home </a>

                            </li>
                            <?php foreach (array_slice($categories, 0, 6) as $key => $value): ?>
                            <li class="nav-item"><a class="nav-link"
                                    href="<?=base_url('category/' . $value['TermSlug'])?>"> <?=$value['TermName']?> </a>
                            </li>
                            <?php endforeach;?>
                            <?php if (count($categories) > 6): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link active dropdown-toggle" href="#" data-toggle="dropdown"> More Items
                                </a>
                                <ul class="dropdown-menu dropdown-menu-left">
                                    <?php foreach (array_slice($categories, 6) as $key => $value): ?>
                                    <li><a class="dropdown-item"
                                            href="<?=base_url('category/' . $value['TermSlug'])?>"><?=$value['TermName']?></a>
                                    </li>
                                    <?php endforeach;?>
                                </ul>
                            </li>
                            <?php endif?>



                        </ul>


                        <!-- Search bar.// -->
                        <ul class="navbar-nav ">
                            <li class="nav-item search hidden-xs hidden-sm "> <a class="nav-link" href="javascript:;;">
                                    <i class="fa fa-search"></i>
                                </a>
                            </li>
                        </ul>
                        <!-- Search content bar.// -->
                        <div class="top-search navigation-shadow">
                            <div class="container">
                                <div class="input-group ">
                                    <form action="<?=base_url('search')?>" method="GET">

                                        <div class="row no-gutters mt-3">
                                            <div class="col">
                                                <input class="form-control border-secondary border-right-0 rounded-0"
                                                    type="search"
                                                    value="<?php echo isset($_GET['q']) ? $_GET['q'] : ''; ?>" name="q"
                                                    placeholder="Search " id="example-search-input4">
                                            </div>
                                            <div class="col-auto">
                                                <a class="btn btn-outline-secondary border-left-0 rounded-0 rounded-right"
                                                    href="<?=base_url('search')?>?q=<?php echo isset($_GET['q']) ? $_GET['q'] : ''; ?>">
                                                    <i class="fa fa-search"></i>
                                                </a>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Search content bar.// -->
                    </div> <!-- navbar-collapse.// -->
                </div>
            </nav>
        </div>
        <!-- End Navbar menu  -->

        <!-- Navbar sidebar menu  -->
        <div id="modal_aside_right" class="modal fixed-left fade" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-aside" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="widget__form-search-bar  ">
                            <div class="row no-gutters">
                                <div class="col">
                                    <input class="form-control border-secondary border-right-0 rounded-0"
                                        value="<?php echo isset($_GET['q']) ? $_GET['q'] : ''; ?>" name="q"
                                        placeholder="Search">
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn-outline-secondary border-left-0 rounded-0 rounded-right">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <nav class="list-group list-group-flush">
                            <ul class="navbar-nav ">
                                <li class="nav-item ">
                                    <a class="nav-link activetext-dark" href="<?=base_url()?>"> Home
                                    </a>

                                </li>
                                <?php foreach ($categories as $key => $value): ?>
                                <li class="nav-item"><a class="nav-link  text-dark"
                                        href="<?=base_url('category/' . $value['TermSlug'])?>"> <?=$value['TermName']?>
                                    </a></li>
                                <?php endforeach;?>
                            </ul>

                        </nav>
                    </div>
                    <!--         <div class="modal-footer">
                        <p>© 2020 <a href="http://retenvi.com/"
                                title="Premium WordPress news &amp; magazine theme">Magzrenvi</a>
                            -
                            Premium template news, blog & magazine &amp;
                            magazine theme by <a href="http://retenvi.com/" title="retenvi">RETENVI.COM</a>.</p>
                    </div> -->
                </div>
            </div> <!-- modal-bialog .// -->
        </div> <!-- modal.// -->
        <!-- End Navbar sidebar menu  -->
        <!-- End Navbar  -->
    </header>
    <!-- End Header news -->