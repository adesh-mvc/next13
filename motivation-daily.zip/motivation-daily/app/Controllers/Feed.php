<?php
 
namespace App\Controllers;
use App\Models\CommonModel;
use CodeIgniter\Controller;
class Feed extends Controller
{
      public function __construct()
    {
      helper('xml');

	
        $this->model = new CommonModel();
        
    }
    
    function index()
    {    
        $data['encoding'] = 'utf-8';    
        $data['feed_name'] = 'www.fashionsootra.com';        
        $data['feed_url'] = 'https://www.fashionsootra.com';        
        $data['page_description'] = 'Fashion Sootra | Your Daily Fashion And Beauty News';       
        $data['page_language'] = 'en-us';        
        $data['creator_email'] = 'support@fashionsootra.com';        
        $query = $this->model->getFeedArticles();  
    
        $data['ARTICLE_DETAILS'] = null;        
        if ($query) {           
            $data['ARTICLE_DETAILS'] = $query;           
        }
            header("Content-Type: text/xml");      

        view('feed', $data);      

    }   
}
?>