<div class="n-layout__row n-layout__row--content">
    <div>



        <div role="navigation" aria-label="category navigation" class="sub-header" data-trackable="sub-header">



            <div class="o-grid-container">

                <div class="o-grid-row">

                    <div class="sub-header__section sub-header__section--title " data-o-grid-colspan="12 M8 XL9">


                        <h1 class="o-teaser-collection__heading o-teaser-collection__heading--full-width">
                            Search
                            result for : <?php echo $_GET['q']; ?>
                        </h1>

                        <h2 class="o-teaser-collection__heading o-teaser-collection__heading--full-width"
                            aria-label="Latest News in Technology">

                        </h2>




                    </div>
                </div>
            </div>
        </div>



        <div role="main" id="site-content" data-concept-id="e58e66fe-7cc6-4382-b781-1161bae8b905">

            <div class="o-grid-container">
                <div class="o-grid-row">
                    <div data-o-grid-colspan="12">
                        <div class="css-grid__container">

                            <!-- top -->
                            <div class="css-grid__item-top">

                                <?php if ($search): ?>
                                <div class="o-grid-row" id="content_masonry">
                                    <?php

                                    foreach ($search as $key => $value):

                                        $title = strlen($value->PostTitle) > 40 ? substr($value->PostTitle, 0, 40) . "..." : $value->PostTitle;
                                        $slug = base_url($value->PostSlug);

                                        $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                                        $thumb_url = $value->PostThumbUrl;

                                        ?>


                                    <div class=" js-track-scroll-event" data-o-grid-colspan="12 L6">
                                        <div class="o-teaser-collection" data-trackable="top-stories-column-one">


                                            <div class="o-teaser o-teaser--article o-teaser--large o-teaser--has-image js-teaser"
                                                data-id="9277dc72-0b64-47ca-a62f-a90f9a5086d8">
                                                <div class="o-teaser__content">

                                                    <div class="o-teaser__heading"><a href="<?= $slug?>"
                                                            data-trackable="heading-link"
                                                            class="js-teaser-heading-link"><?= $title?> </a></div>
                                                    <p class="o-teaser__standfirst"><a href="<?= $slug?>"
                                                            data-trackable="standfirst-link" tabindex="-1"
                                                            class="js-teaser-standfirst-link"><?= $content?></a>


                                                        <span class="o-teaser__meta"><a class="o-teaser__tag"
                                                                data-trackable="teaser-tag" href="<?= $slug?>">Read
                                                                More...</a></span>
                                                    </p>

                                                </div>
                                                <div class="o-teaser__image-container js-teaser-image-container">
                                                    <a href="<?= $slug?>" data-trackable="image-link" tabindex="-1"
                                                        aria-hidden="true">
                                                        <div class="o-teaser__image-placeholder"
                                                            style="padding-bottom:56.2471%;"><img
                                                                class="o-teaser__image" src="<?= $thumb_url?>"
                                                                alt="<?= $title?>">
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                    <?php endforeach?>

                                </div>



                                <?php else: ?>

                                <h2 class="o-teaser-collection__heading o-teaser-collection__heading--full-width"
                                    aria-label="Latest News in Technology">
                                    No Post Found
                                </h2>
                                <?php endif;?>
                            </div>

                            <!-- right sidebar -->
                            <div class="css-grid__sidebar">
                                <?= $this->include('include/sidebar')?>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>