<div class="main_title_wrapper category_title_section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 main_title_col">
                <div class="jl_cat_mid_title">
                    <h3 class="categories-title title"><?=$PostDetails->PageTitle?></h3>
                </div>
            </div>
        </div>
    </div>
</div>

<section id="content_main" class="clearfix">
    <div class="container">
        <div class="row main_content">
            <!-- begin content -->
            <div class="page-full col-md-12 post-3938 page type-page status-publish hentry" id="content">
                <div class="content_single_page post-3938 page type-page status-publish hentry">
                    <div class="content_page_padding">
                        <div class="woocommerce">
                            <div class="woocommerce-notices-wrapper"></div>
                            <?=$PostDetails->PageContent?>
                        </div>
                    </div>
                    <div class="brack_space"></div>
                </div>
            </div>
        </div>
    </div>
</section>