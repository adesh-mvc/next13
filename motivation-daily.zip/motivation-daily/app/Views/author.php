
<div class="g1-row-inner" >
   <!--AD Body Start-->
	                   <?=$settings->HeaderAds;?>
   <!--AD Body End-->
</div>
<div class="g1-primary-max">
   <div id="content" role="main">
      <article id="post-3873" class="post-3873 page type-page status-publish" itemscope=""
         itemtype="http://schema.org/WebPage">
         <header class="page-header page-header-01 g1-row g1-row-layout-page">
            <div class="g1-row-inner">
               <div class="g1-column">
                  <nav class="g1-breadcrumbs g1-breadcrumbs-with-ellipsis g1-meta">
                     <p class="g1-breadcrumbs-label">You are here: </p>
                     <ol itemscope itemtype="http://schema.org/BreadcrumbList">
                        <li class="g1-breadcrumbs-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                           <a itemprop="item" content="<?=base_url();?>" href="<?=base_url();?>">
                              <span itemprop="name">Home</span>
                              <meta itemprop="position" content="1" />
                           </a>
                        </li>
                        <li class="g1-breadcrumbs-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                           <span itemprop="name">Authors</span>
                           <meta itemprop="position" content="2" />
                           <meta itemprop="item" content="Authors" />
                        </li>
                     </ol>
                  </nav>
               </div>
            </div>
            <div class="g1-row-background">
            </div>
         </header>
         <div class="page-body g1-row g1-row-layout-page g1-row-padding-m">
            <div class="g1-row-background">
            </div>
            <div class="g1-row-inner">
               <div id="primary" class="g1-column g1-column-2of3">
                  <div class="entry-content" itemprop="text" >
                     <main class="about">

  <div class="container">
    <section class="grid info">
      <div class="column-xs-12 column-md-1">
        <div class="about">
        <h1 class="section-heading">About Authors</h1>
        </div>
      </div>
      
      <div class="column-xs-10 column-md-7">
        <div class="intro">
          <h2>Rashmi is an award-winning author and fashion blogger.</h2>
          <p>Rashmi at fashionsootra writes blog articles that inspires all fashion & beauty lovers.</p>
	  <p>She works as a freelance writer who uses the blog to share all of her passions with her readers.</p>
          <p>Apart from fashion, the blog also features a <b><a href="https://www.fashionsootra.com/category/culture">Culture</a></b> section where readers can learn more about trends, the arts, and shows.</p>
        </div>
      </div>

      <div class="column-xs-10 column-md-7">
        <div class="intro">
          <h2>Bhawna, A fashion blogger with a passion for fashion, beauty, and culture brings all of it together</h2>
          <p>She personally writes each one of her posts which vary from fashion and beauty to trends, fashion and then some more! </p>
	  <p>From trend-spotting at the Indian Fashion Weeks, reviews of collections, outfit posts, unique products, jewellery and accessories, to other fashion-related events, she writes about whatever seems to catch her fancy at the time.</p>
	   <p> She lets you peek into her personal style and gives you a glimpse of the fashion world with a twist!</p>
        </div>
      </div>
      
    </section>
  </div>
</main>

                  </div>
                  <!-- .entry-content -->
               </div>
               <div id="secondary" class="g1-sidebar g1-sidebar-padded g1-column g1-column-1of3">
                  <aside id="custom_html-10" class="widget_text widget widget_custom_html">
                     <div class="textwidget custom-html-widget">
			<!--AD Body Start-->
				<?=$settings->SidebarAds;?>
			<!--AD Body End-->

			</div>
                  </aside>
               </div>
               <!-- #secondary -->
            </div>
         </div>
      </article>
      <!-- #post-## -->

   </div>
   <!-- #content -->
</div>
<!-- #primary -->
<div class="g1-row-inner">
<?=$settings->FooterAds;?>
</div>
