<section class="pb-80">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Breadcrumb -->
                <ul class="breadcrumbs bg-light mb-4">
                    <li class="breadcrumbs__item">
                        <a href="<?=base_url()?>" class="breadcrumbs__url">
                            <i class="fa fa-home"></i> Home</a>
                    </li>
                    <li class="breadcrumbs__item">
                        <a href="<?=base_url('category/' . $categories[$CatId]['TermSlug']);?>"
                            class="breadcrumbs__url"><?=$categories[$CatId]['TermName'];?></a>
                    </li>
                    <li class="breadcrumbs__item breadcrumbs__item--current">
                        <?=$PostDetails->PostTitle;?>
                    </li>
                </ul>
            </div>
            <div class="col-md-8">

                <!-- Article Detail -->
                <div class="wrap__article-detail">
                    <div class="wrap__article-detail-title">
                        <h1>
                            <?=$PostDetails->PostTitle;?>
                        </h1>

                    </div>
                    <hr>
                    <div class="wrap__article-detail-info">
                        <ul class="list-inline">


                            <li class="list-inline-item">
                                <span class="text-dark text-capitalize ml-1">
                                    <?=date('F d, Y', strtotime($PostDetails->Date));?>
                                </span>
                            </li>
                            <li class="list-inline-item">
                                <span class="text-dark text-capitalize">
                                    in
                                </span>
                                <a href="<?=base_url('category/' . $categories[$CatId]['TermSlug']);?>">
                                    <?=$categories[$CatId]['TermName'];?>
                                </a>


                            </li>
                        </ul>
                    </div>

                    <div class="wrap__article-detail-image mt-4">
                        <figure>
                            <img src="<?=$PostDetails->PostThumbUrl?>" alt=" <?=$PostDetails->PostTitle;?>"
                                class="img-fluid">
                        </figure>
                    </div>
                    <div class="wrap__article-detail-content">

                        <?php
$strings = $article_ads->create_html(iconv('UTF-8', 'ISO-8859-1//IGNORE', $PostDetails->PostContent), '', $settings->FooterAds);
$from = array('&lt;', '&gt;');
$to = array('<', '>');
$string = str_replace($from, $to, $strings);
echo htmlspecialchars_decode($strings);
?>
                    </div>


                </div>






                <div class="row">
                    <?php if ($prev_blog): ?>
                    <div class="col-md-6">
                        <div class="single_navigation-prev">
                            <a href="<?=base_url($prev_blog['PostSlug']);?>">
                                <span>previous post</span>
                                <?=substr($prev_blog['PostTitle'], 0, 45)?>
                            </a>
                        </div>
                    </div>
                    <?php endif?>
                    <?php if ($next_blog): ?>
                    <div class="col-md-6">
                        <div class="single_navigation-next text-left text-md-right">
                            <a href="<?=base_url($next_blog['PostSlug']);?>">
                                <span>next post</span>
                                <?=substr($next_blog['PostTitle'], 0, 45)?>
                            </a>
                        </div>
                    </div>
                    <?php endif?>
                </div>
                <div class="clearfix"></div>

                <div class="related-article bg-light">
                    <h4>
                        you may also like
                    </h4>

                    <div class="article__entry-carousel-three">
                        <?php

$popular = $controller->posts(rand(5, 25), 6);
foreach ($popular as $key => $value):
    shuffle($color);
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
    $title = strlen($post_title) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($post_title)), 0, 10)) . '...' : $post_title;

    $thumb_url = $value->PostThumbUrl;

    ?>
                        <div class="item">
                            <!-- Post Article -->
                            <div class="article__entry">
                                <div class="article__image">
                                    <a href="<?=$slug?>">
                                        <img src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid">
                                    </a>
                                </div>
                                <div class="article__content">
                                    <ul class="list-inline">

                                        <li class="list-inline-item">
                                            <span>
                                                <?=date('F d, Y', strtotime($value->Date));?>
                                            </span>
                                        </li>

                                    </ul>
                                    <h5>
                                        <a href="<?=$slug?>">
                                            <?=$title?>
                                        </a>
                                    </h5>

                                </div>
                            </div>
                        </div>
                        <?php endforeach?>
                    </div>
                </div>

            </div>
            <div class="col-md-4">
                <?=$this->include('include/sidebar')?>
            </div>
        </div>
    </div>
</section>