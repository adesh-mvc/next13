<?php
	$i=0;
	$IsNumber=0;
	

	foreach ($products as $key => $value):
	if(!empty($tag)){
		$AffCode=str_replace("fashionsootra-21", $tag,$value->AffCode);
	}else{
		$AffCode=$value->AffCode;
	}
	$i++;
        $IsNumber++;

	if($i%3==0){
		$AffCode =  str_replace("ffffff", 'ff0036',$AffCode);
		$AffCode =  str_replace("0066c0", 'ffffff',$AffCode);
		$AffCode =  str_replace("333333", 'ffffff',$AffCode);
	}else{
		$AffCode =  str_replace("0066c0", '000000',$AffCode);
		$AffCode =  str_replace("333333", '000000',$AffCode);
	}
	if($i%6==0){
	
	?>
	<div class="row parent">
	<?php } ?>
	<div class="columns">
	
		<?=$AffCode;?>
	</div>
	<?php
	if($i%6==0){
	?>
	</div>  
	<?php } ?>  
	<?php endforeach ?>
