<div class="breadcrumb wrapper font-default">

    <a title="Entertainment" href="<?=base_url('category/' . $categories[$CatId]['TermSlug']);?>"
        class="article-object-link opt-internal">"<?=$categories[$CatId]['TermName'];?></a>


</div>


<div class="wrapper content">
    <div id="content">
        <article class="article POST">
            <span itemprop="image" style="display: none" itemscope="" itemtype="https://schema.org/ImageObject">
                <meta itemprop="url" content="<?=$PostDetails->PostThumbUrl?>">
                <meta itemprop="width" content="1920">
                <meta itemprop="height" content="1080">
            </span>
            <h1 id="id_title"><?=$PostDetails->PostTitle;?></h1>

            <div class="byline font-default">




                <time>&nbsp;<?=date('M d, Y', strtotime($PostDetails->Date));?></time>
            </div>





            <hr class="tophz">







            <div class="text-content">
                <div class="main-container">
                    <div class="breadcrumb wrapper font-default">
                        <svg>
                            <use href="/s/mashable/spritemap.svg#sprite-logomark"></use>
                        </svg> &gt;
                        Entertainment
                    </div>
                    <div id="id_text" itemprop="articleBody">

                        <p>

                            <?php
$strings = $article_ads->create_html(iconv('UTF-8', 'ISO-8859-1//IGNORE', $PostDetails->PostContent), '', $settings->FooterAds);
$from = array('&lt;', '&gt;');
$to = array('<', '>');
$string = str_replace($from, $to, $strings);
echo htmlspecialchars_decode($strings); ?>
                        </p>

                    </div>
                    <div class="topics"><span class="font-bold">Topics</span>: <a
                            href="/entertainment">Entertainment</a>, <a href="/entertainment-1">Entertainment</a>, <a
                            href="/bollywood">Bollywood</a>, <a href="/shahid-kapoor">Shahid Kapoor</a></div>

                </div>


                <section class="sidebar">

                    <div class="zad halfpage" data-zadtype="halfpage" data-suffix="_mrec1"></div>
                </section>

            </div>
            <div class="mobileAds">
                <div class="zad halfpage" data-zadtype="halfpage" data-suffix="_mrec1"></div>
            </div>
        </article>
        <div class="text-content bottom">
            <div class="main-container">
                <h3>Recommended For You</h3>
                <div id="new">
                    <ul id="wn" data-pagenum="1">

                        <li class="blogroll POST">
                            <a
                                href="https://in.mashable.com/entertainment/54515/dark-phoenix-to-fantastic-four-popular-marvel-films-that-tanked-at-the-box-office">
                                <div>
                                    <img src="img/untitled-design-2023-06-14t164951094_j13j.320.jpg" alt="0"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/untitled-design-2023-06-14t164951094_j13j.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/untitled-design-2023-06-14t164951094_j13j.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">Dark Phoenix To Fantastic Four, Popular Marvel Films That
                                        Tanked At The Box Office</div>
                                    <div class="deck"></div>
                                    <time class="datepublished">June 14, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll POST">
                            <a
                                href="https://in.mashable.com/entertainment/54514/the-flash-review-surprising-cameos-ezra-millers-acting-and-more-reasons-to-watch-or-skip-new-dceu-fi">
                                <div>
                                    <img src="img/untitled-design-2023-06-14t163749501_f2ee.320.jpg" alt="0"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/untitled-design-2023-06-14t163749501_f2ee.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/untitled-design-2023-06-14t163749501_f2ee.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">The Flash Review: Surprising Cameos, Ezra Miller's Acting And
                                        More Reasons To Watch Or Skip New DCEU Film</div>
                                    <div class="deck"></div>
                                    <time class="datepublished">June 14, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll POST">
                            <a
                                href="https://in.mashable.com/entertainment/54509/blackpinks-jennie-and-anushka-sharma-named-as-most-visible-artists-at-cannes-film-festival">
                                <div>
                                    <img src="img/anushka-sharma_4ba4.320.jpg" alt="0"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/anushka-sharma_4ba4.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/anushka-sharma_4ba4.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">Blackpink's Jennie And Anushka Sharma, Named As Most Visible
                                        Artists At Cannes Film Festival</div>
                                    <div class="deck"></div>
                                    <time class="datepublished">June 14, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll POST">
                            <a
                                href="https://in.mashable.com/entertainment/54487/tiku-weds-sheru-trailer-nawazuddin-siddiqui-romancing-21-year-old-avneet-kaur-will-make-you-cringe">
                                <div>
                                    <img src="img/4-1_1vzk.320.jpg" alt="0"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/4-1_1vzk.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/4-1_1vzk.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">Tiku Weds Sheru Trailer: Nawazuddin Siddiqui Romancing
                                        21-Year-Old Avneet Kaur Will Make You Cringe</div>
                                    <div class="deck">The trailer for Tiku Weds Sheru, starring Nawazuddin Siddiqui and
                                        Avneet Kaur, has been dropped by the makers on the internet.</div>
                                    <time class="datepublished">June 14, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll POST">
                            <a
                                href="https://in.mashable.com/entertainment/54507/not-cool-internet-is-enraged-as-female-fan-forcefully-kisses-shah-rukh-khan-in-viral-video-watch">
                                <div>
                                    <img src="img/yeh-jawani-hai-deewani-to-silsila-bollywood-movies-to-watch_58t2.320.png"
                                        alt="0"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/yeh-jawani-hai-deewani-to-silsila-bollywood-movies-to-watch_58t2.320.png 1x, https://sm.mashable.com/t/mashable_in/photo/default/yeh-jawani-hai-deewani-to-silsila-bollywood-movies-to-watch_58t2.640.png 2x">
                                </div>
                                <div>
                                    <div class="caption">'Not Cool!' Internet Is Enraged As Female Fan Forcefully Kisses
                                        Shah Rukh Khan In Viral Video; Watch</div>
                                    <div class="deck">Netizens were enraged as a video of a female fan forcefully
                                        kissing Shah Rukh Khan went viral on the internet.</div>
                                    <time class="datepublished">June 14, 2023</time>
                                </div>
                            </a>
                        </li>

                    </ul>
                </div>

                <h3 class="trendingbar">Trending on Mashable</h3>
                <div id="new">
                    <ul id="wn">

                        <li class="blogroll ">
                            <a
                                href="/culture/54367/whenever-they-show-her-something-bad-happens-netizens-blame-anushka-sharma-for-team-indias-defeat-in">
                                <div>
                                    <img src="img/img-6643_5jxq.320.jpg"
                                        alt="‘Whenever They Show Her, Something Bad Happens’ Netizens Blame Anushka Sharma For Team India's Defeat In WTC Final"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/img-6643_5jxq.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/img-6643_5jxq.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">‘Whenever They Show Her, Something Bad Happens’ Netizens Blame
                                        Anushka Sharma For Team India's Defeat In WTC Final</div>
                                    <div class="deck">Anushka Sharma called 'panauti' by fans after team India's loss in
                                        WTC finals</div>
                                    <time class="datepublished">June 12, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll ">
                            <a
                                href="/entertainment/54246/bloody-daddy-twitter-review-netizens-call-shahid-kapoor-the-only-good-thing-in-the-movie">
                                <div>
                                    <img src="img/bloody-daddy-copy_qmnz.320.jpg"
                                        alt="Bloody Daddy Twitter Review: Netizens Call Shahid Kapoor 'The Only Good Thing' In The Movie"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/bloody-daddy-copy_qmnz.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/bloody-daddy-copy_qmnz.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">Bloody Daddy Twitter Review: Netizens Call Shahid Kapoor 'The
                                        Only Good Thing' In The Movie</div>
                                    <div class="deck">What do you guys think?</div>
                                    <time class="datepublished">June 9, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll ">
                            <a
                                href="/entertainment/53950/after-14-years-harman-bawejas-transformation-for-scoop-takes-internet-by-surprise-and-we-can-see-why">
                                <div>
                                    <img src="img/scoop-1_kcyc.320.jpg"
                                        alt="After 14 Years Harman Baweja's Transformation For Scoop Takes Internet By Surprise And We Can See Why"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/scoop-1_kcyc.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/scoop-1_kcyc.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">After 14 Years Harman Baweja's Transformation For Scoop Takes
                                        Internet By Surprise And We Can See Why</div>
                                    <div class="deck">Back to the future!</div>
                                    <time class="datepublished">June 5, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll ">
                            <a
                                href="/entertainment/53867/zara-hatke-zara-bachke-twitter-review-fans-say-sara-ali-khan-vicky-kaushal-starrer-is-a-not-so-great">
                                <div>
                                    <img src="img/untitled-design-2023-06-02t144336471_u3y7.320.jpg"
                                        alt="Zara Hatke Zara Bachke Twitter Review: Fans Say Sara Ali Khan-Vicky Kaushal Starrer Is A 'Not-So-Great Film' But.."
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/untitled-design-2023-06-02t144336471_u3y7.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/untitled-design-2023-06-02t144336471_u3y7.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">Zara Hatke Zara Bachke Twitter Review: Fans Say Sara Ali
                                        Khan-Vicky Kaushal Starrer Is A 'Not-So-Great Film' But..</div>
                                    <div class="deck">The internet seems to like Sara Ali Khan-Vicky Kaushal starrer
                                    </div>
                                    <time class="datepublished">June 2, 2023</time>
                                </div>
                            </a>
                        </li>

                        <li class="blogroll ">
                            <a
                                href="/entertainment/53861/mockery-of-history-family-members-of-netaji-bose-khudiram-bose-react-to-claims-made-in-veer-savarkar">
                                <div>
                                    <img src="img/2scw_zbej.320.jpg"
                                        alt="'Mockery Of History' Family Members Of Netaji Bose, Khudiram Bose React To Claims Made In Veer Savarkar's Film"
                                        srcset="https://sm.mashable.com/t/mashable_in/photo/default/2scw_zbej.320.jpg 1x, https://sm.mashable.com/t/mashable_in/photo/default/2scw_zbej.640.jpg 2x">
                                </div>
                                <div>
                                    <div class="caption">'Mockery Of History' Family Members Of Netaji Bose, Khudiram
                                        Bose React To Claims Made In Veer Savarkar's Film</div>
                                    <div class="deck">Family members of Netaji Bose and Khudiram Bose slam the claims
                                        made in the film, Swatantra Veer Savarkar</div>
                                    <time class="datepublished">June 2, 2023</time>
                                </div>
                            </a>
                        </li>

                    </ul>
                </div>

            </div>
            <section class="sidebar">
                <div class="zad halfpage" data-zadtype="halfpage" data-suffix="_mrec1"></div>
            </section>
        </div>

    </div>
</div>