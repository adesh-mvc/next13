<?php if (trim($settings->SidebarAds)): ?>
<div id="nemesis_ads_widget-2" class="widget clearfix nemesis-ad-block">
    <div class="fbt-ads text-center">
        <div class="fbt-ad-content">
            <?=$settings->SidebarAds;?>
        </div>
    </div>
</div>
<?php endif;?>



<div class="css-grid__sidebar-item">


    <div class="o-ads advert--mid-small-medium" data-o-ads-name="mid-small" data-o-ads-targeting="pos=mid;"
        data-o-ads-center="true" data-o-ads-label="false" data-o-ads-formats-small="MediumRectangle,Responsive,OneByOne"
        data-o-ads-formats-medium="false" data-o-ads-formats-large="false" data-o-ads-formats-extra="false"
        aria-hidden="true">
    </div>
</div>

<aside data-o-grid-colspan="12" class="aside--community" data-trackable="aside-section">
    <div class="o-teaser-community__header">
        <div>
            <h2 class="o-teaser-community__heading">
                <a data-trackable="aside-section-title" href="javascript:(0)">Recent Post</a>
            </h2>
        </div>

    </div>
    <div class="o-teaser-community__content">
        <?php
$sidebar = $controller->posts(0, 11,array('PostContent'));

foreach ($sidebar as $key => $value):
    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $post_title = iconv('UTF-8', 'ISO-8859-1//IGNORE', $value->PostTitle);
   // $title = strlen($post_title) > 45 ? substr($post_title, 0, 45) . '...' : "<br>" . $post_title;
    $thumb_url = $value->PostThumbUrl;
    $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 15));
    ?>
        <div class="event-teaser" data-trackable="event-teaser"
            data-trackable-context-content-id="754c53cc977dd96d8492f91423900a3a" data-o-tracking-view="true">
            <div class="event-teaser__content-container">
                <div class="event-teaser__details">
                    <div class="event-teaser__title-heading" role="heading" aria-level="4">
                        <a class="event-teaser__title" data-trackable="event-teaser-title" href="<?= $slug?>"
                            title="<?=$post_title?>"><?=$post_title?></a>
                    </div>
                    <span class="event-teaser__standfirst"><?=$content?>...</span>
                </div>
                <div class="event-teaser__footer"><span class="event-teaser__timestamp"><time
                            datetime="2023-05-17T12:00:00.000Z">
                            <?=date('l jS, M, Y', strtotime($value->Date))?></time></span><span
                        class="event-teaser__location"><?= $CategoryName?></span></div>
            </div>
        </div>
        <?php endforeach?>
    </div>

</aside>