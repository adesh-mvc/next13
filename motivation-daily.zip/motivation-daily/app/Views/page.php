<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- breadcrumb -->
                <!-- Breadcrumb -->
                <ul class="breadcrumbs bg-light mb-4">
                    <li class="breadcrumbs__item">
                        <a href="<?=base_url()?>" class="breadcrumbs__url">
                            <i class="fa fa-home"></i> Home</a>
                    </li>

                    <li class="breadcrumbs__item breadcrumbs__item--current">
                        <?=$PostDetails->PageTitle?>
                    </li>
                </ul>
                <!-- End breadcrumb -->

                <div class="wrap__about-us">
                    <h2><?=$PostDetails->PageTitle?></h2>

                    <?=$PostDetails->PageContent?>
                </div>
            </div>


        </div>
    </div>
</section>