<!--AD Body Start-->
<?php if (!empty($_GET['static'])) {?>
<div id="advertize_content"> Advertize Content One
    <?=$settings->HeaderAds;?>
</div>
<?php } else {?>
<?=$settings->HeaderAds;?>
<?php }?>
<?php $category_name = $categories[$CatId]['TermName'];
$category_slug = base_url('category/' . $categories[$CatId]['TermSlug']);
?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Breadcrumb -->
                <ul class="breadcrumbs bg-light mb-4">
                    <li class="breadcrumbs__item">
                        <a href="<?=base_url()?>" class="breadcrumbs__url">
                            <i class="fa fa-home"></i> Home</a>
                    </li>
                    <li class="breadcrumbs__item">
                        <a href="<?=base_url()?>" class="breadcrumbs__url">Category</a>
                    </li>
                    <li class="breadcrumbs__item breadcrumbs__item--current">
                        <?=$category_name?>
                    </li>
                </ul>
            </div>

        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <aside class="wrapper__list__article ">
                    <h4 class="border_section"> <?=$category_name?></h4>
                    <?php $IsWhere = array('CatId' => $CatId);
$categories_array = $controller->posts(0, $show_limit, array('PostContent'), $IsWhere);
if (is_countable($categories_array) && count($categories_array)):
?>
                    <div class="row" id="primary">
                        <?php

foreach ($categories_array as $key => $value):

    $title = strlen($value->PostTitle) > 40 ? substr($value->PostTitle, 0, 40) . "..." : $value->PostTitle;
    $slug = base_url($value->PostSlug);

    $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
    $thumb_url = $value->PostThumbUrl;

    ?>
                        <div class="col-md-6 bg-light">
                            <!-- Post Article -->
                            <div class="article__entry">
                                <div class="article__image">
                                    <a href="<?=$slug?>">
                                        <img data-src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid lazy">
                                    </a>
                                </div>
                                <div class="article__content">
                                    <div class="article__category">
                                        <?=$category_name?> </div>
                                    <ul class="list-inline">

                                        <li class="list-inline-item">
                                            <span class="text-dark text-capitalize">
                                                <?=date('F d, Y', strtotime($value->Date));?>
                                            </span>
                                        </li>

                                    </ul>
                                    <h5>
                                        <a href="<?=$slug?>">
                                            <?=$title?>
                                        </a>
                                    </h5>
                                    <p>
                                        <?=$content?>
                                    </p>
                                    <a href="<?=$slug?>" class="btn btn-outline-primary mb-4 text-capitalize"> read
                                        more</a>
                                </div>
                            </div>


                        </div>
                        <?php endforeach?>

                    </div>
                    <div class="pagination-area">
                        <div class="pagination wow fadeIn animated" data-wow-duration="2s" data-wow-delay="0.5s"
                            style="visibility: visible; animation-duration: 2s; animation-delay: 0.5s; animation-name: fadeIn;">

                            <a class="active" href="javascript:;;" id="loadItems">
                                Load More
                            </a>


                        </div>
                    </div>
                    <?php else: ?>
                    <div class="pagination-area">
                        <div class="pagination wow fadeIn animated" data-wow-duration="2s" data-wow-delay="0.5s"
                            style="visibility: visible; animation-duration: 2s; animation-delay: 0.5s; animation-name: fadeIn;">

                            <a class="active" href="javascript:;;">
                                -------------No Data Found-------------
                            </a>


                        </div>
                    </div>
                    <?php endif;?>
                </aside>

            </div>
            <div class="col-md-4">
                <?=$this->include('include/sidebar')?>
            </div>

            <div class="clearfix"></div>
        </div>

    </div>
</section>





<!-- end content -->
<script>
const loadButton = document.getElementById("loadItems");
if (document.contains(loadButton)) {
    //alert();
}
const category = "<?=$category_slug;?>";

var page = "<?php echo $page; ?>";
loadButton.addEventListener("click", function(e) {
    e.preventDefault();
    page++;

    xhrRequest(page);
});

function xhrRequest(page) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", `<?=site_url('category/add/')?>${page}/${<?=$CatId?>}`, true);
    xhr.onload = function() {
        if (xhr.readyState === xhr.DONE) {
            if (xhr.status === 200) {
                // console.log(xhr.responseText);
                if (xhr.responseText != "finished") {
                    //  console.log(xhr.response)
                    document
                        .getElementById("primary")
                        .insertAdjacentHTML("beforeend", xhr.response);
                    if (page > 2)
                        history.pushState("/home", "Title", `${category}/page/${page}`);
                    else history.pushState("/home", "Title", `${category}/page/${page}`);
                } else {
                    // loadButton.disabled = true;
                    loadButton.style.opacity = .8;
                    loadButton.style.pointerEvents = 'none';
                    loadButton.parentNode.classList.add('active');
                    console.log(loadButton.parentNode)
                    loadButton.innerHTML = "You have reached the end.";
                }
            }
        }
    };
    xhr.send();
}
</script>