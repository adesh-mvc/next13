<!DOCTYPE html>
<html lang="en-GB"
    class="no-js core o-typography--loading-sans o-typography--loading-sans-bold o-typography--loading-display o-typography--loading-display-bold"
    data-o-component="o-typography" style="overflow-x:hidden;background-color:#fff1e5;color:#33302e">
<?php
$router = service('router');
 $method = $router->methodName(); 
$CampID = 0;
$IsPageTitle = str_replace('-', ' ', explode("/", $_SERVER['REQUEST_URI']));
$IsLength = count($IsPageTitle);
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        <?php if (!empty($IsPageTitle[$IsLength - 1])) {echo ucfirst($IsPageTitle[$IsLength - 1]) . ' | ';}?><?=$settings->SiteTitle;?>
    </title>





    <link rel="preload" as="font"
        href="https://www.ft.com/__origami/service/build/v3/font?font_format=woff2&amp;font_name=MetricWeb-Regular&amp;system_code=origami&amp;version=1.12"
        type="font/woff2" crossorigin="anonymous">
    <link rel="preload" as="font"
        href="https://www.ft.com/__origami/service/build/v3/font?font_format=woff2&amp;font_name=MetricWeb-Semibold&amp;system_code=origami&amp;version=1.12"
        type="font/woff2" crossorigin="anonymous">
    <link rel="preload" as="font"
        href="https://www.ft.com/__origami/service/build/v3/font?font_format=woff2&amp;font_name=FinancierDisplayWeb-Regular&amp;system_code=origami&amp;version=1.12"
        type="font/woff2" crossorigin="anonymous">
    <link rel="preload" as="font"
        href="https://www.ft.com/__origami/service/build/v3/font?font_format=woff2&amp;font_name=FinancierDisplayWeb-Bold&amp;system_code=origami&amp;version=1.12"
        type="font/woff2" crossorigin="anonymous">
    <!--GA Start-->
    <?=$settings->MetaVerification;?>
    <?=$settings->SeoInfo;?>
    <!--GA End-->
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <?php if ($method == 'article') {
    $description = implode(' ', array_slice(explode(' ', strip_tags($PostDetails->PostContent)), 0, 30));
    ?>
    <meta name="description" content="<?=$description;?>">
    <?php } else {?>
    <meta name="description" content="">
    <?php }?>

    <?php if($method == 'category' || $method =='search'):?>
    <link rel="stylesheet" href="<?= site_url('assets')?>/css/vendors~page-kit-layout-styles.8f1b1221115f.css">
    <link rel="stylesheet" href="<?= site_url('assets')?>/css/styles.7309d55a13f1.css">
    <?php elseif ($method == 'article'):?>
    <link rel="stylesheet" href="<?= site_url('assets')?>/css/vendors~page-kit-layout-styles.6650c7ce90b5.css">
    <link rel="stylesheet" href="<?= site_url('assets')?>/css/main.41b14cfc2c52.css">
    <?php else:?>
    <link rel="stylesheet" href="<?= site_url('assets')?>/css/vendors~page-kit-layout-styles.57c5bce45f85.css">
    <link rel="stylesheet" href="<?= site_url('assets')?>/css/styles.766fe6f15878.css">
    <?php endif;?>
    <script type="application/json" id="page-kit-bootstrap-config">
    {
        "trackErrors": true,
        "core": ["https://polyfill.io/v3/polyfill.min.js?features=HTMLPictureElement&source=next"],
        "enhanced": [
            "https://polyfill.io/v3/polyfill.min.js?features=default%2Ces5%2Ces2015%2Ces2016%2Ces2017%2CEventSource%2Cfetch%2CHTMLPictureElement%2CIntersectionObserver%2CNodeList.prototype.forEach&source=next",
            "https://www.ft.com/__assets/hashed/page-kit/webpack-runtime.fb5e068cad11.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/page-kit-components.f1ee9c1b811e.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-tracking.2105c1bac798.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/shared.stable.00fc70529852.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-n-syndication.f95eb47ab4d8.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-viewport.23fb20fd1a89.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-n-feedback.343e703ec28a.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/privacy-components.27db63a14d09.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-grid.cdce17ebc329.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-utils.d35d8c7a2394.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-footer.ecd26a818094.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-message.a92efafcc920.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-overlay.09ed63bf2911.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-toggle.0cf48066b7e1.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-tooltip.65ab2a9dc843.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-n-tracking.eddf746ac089.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-banner.b0af73e394f7.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-cookie-message.e95ef7281d9f.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-date.c2a540bea29c.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-o-typography.fc026638c98b.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-x-engine.1ba975d35f02.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/superstore.ffb9dad07087.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/react.8efae3892ea5.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/financial-times-n-exponea.8ab4c6ddd057.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/preact.44ad39293e48.bundle.js",
            "https://www.ft.com/__assets/hashed/page-kit/scripts.f2ab10fb618d.bundle.js"
        ]
    }
    </script>
    <script>
    ;
    (function() {
        var doc = document.documentElement
        var isEnhanced = isEnhancedBrowser()
        var scriptsConfig = getScriptsConfig()
        var scriptsToLoad = []
        var currentScript = document.scripts[document.scripts.length - 1]

        doc.className = doc.className.replace('no-js', 'js')

        if (isEnhanced) {
            doc.className = doc.className.replace('core', 'enhanced')
            Array.prototype.push.apply(scriptsToLoad, scriptsConfig.enhanced)
        } else {
            Array.prototype.push.apply(scriptsToLoad, scriptsConfig.core)
        }

        for (var i = 0, len = scriptsToLoad.length; i < len; i++) {
            loadScript(scriptsToLoad[i])
        }

        function scriptLoadError(error) {
            var script = error.target ? error.target.src : null

            if (script) {
                console.error('The script ' + script + ' failed to load') // eslint-disable-line no-console
            }

            if (/enhanced/.test(doc.className)) {
                console.warn(
                    'Script loading failed, reverting to core experience') // eslint-disable-line no-console
                doc.className = doc.className.replace('enhanced', 'core')
            }

            if (scriptsConfig.trackErrors) {
                addErrorTrackingPixel(script)
            }
        }

        function loadScript(src) {
            var script = document.createElement('script')
            script.onerror = scriptLoadError
            script.async = false
            script.src = src
            currentScript.parentNode.insertBefore(script, currentScript)
        }

        // "Cut the mustard" test
        // by Maggie Allen and Matt Hinchliffe November 2018
        function isEnhancedBrowser() {
            var script = document.createElement('script')
            var input = document.createElement('input')

            return (
                'visibilityState' in document && // not supported by old Android (4.0-4.4) without a prefix
                'indeterminate' in input && // not supported by BB 10
                'flex' in doc.style && // not supported by old Safari (< 9) or IE 6-10
                'async' in script // not supported by old Opera (Presto engine < 15)
            )
        }

        function getScriptsConfig() {
            var scriptsConfigEl = document.getElementById('page-kit-bootstrap-config')
            var scriptsConfig = {
                core: [],
                enhanced: [],
                trackErrors: false
            }

            if (scriptsConfigEl) {
                try {
                    scriptsConfig = JSON.parse(scriptsConfigEl.innerHTML)
                } catch (error) {
                    console.error('Bootstrap configuration error', error) // eslint-disable-line no-console
                }
            }

            return scriptsConfig
        }

        function addErrorTrackingPixel(script) {
            var img = new Image()

            var data = JSON.stringify({
                category: 'javascript',
                action: 'load-error',
                system: {
                    source: 'page-kit'
                },
                context: {
                    script: script
                }
            })

            img.src = 'https://spoor-api.ft.com/px.gif?data=' + encodeURIComponent(data)
        }
    })()
    </script>



    <link rel="icon" href="<?=$settings->FavIcon;?>" sizes="32x32" />
    <link rel="icon" href="<?=$settings->FavIcon;?>" sizes="192x192" />
    <link rel="apple-touch-icon-precomposed" href="<?=$settings->FavIcon;?>" />
    <meta name="msapplication-TileImage" content="<?=$settings->FavIcon;?>" />
    <?php if ($method == 'article') {
    $description = implode(' ', array_slice(explode(' ', strip_tags($PostDetails->PostContent)), 0, 20));
    ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="" />
    <meta name="twitter:title" content="<?=$PostDetails->PostTitle;?>" />
    <meta name="twitter:description" content="<?=$description;?>" />
    <meta name="twitter:image" content="<?=$PostDetails->PostThumbUrl;?>" />


    <meta property="og:title" content="<?=$PostDetails->PostTitle;?>">
    <meta property="og:site_name" content=''>
    <meta property="fb:app_id" content="" />
    <meta property="og:url" content="<?=base_url($PostDetails->PostSlug);?>">
    <meta property="og:description" content='<?=$description;?>'>
    <meta property="og:image" content="<?=$PostDetails->PostThumbUrl;?>">
    <meta property="og:image:secure_url" content="<?=$PostDetails->PostThumbUrl;?>">
    <meta property="og:image:type" content="image/jpg"> <!-- recommend type -->
    <meta property="og:image:alt" content=''>
    <meta property="og:image:width" content="1200"> <!-- recommend size -->
    <meta property="og:image:height" content="675"> <!-- recommend size -->
    <meta property="og:type" content="profile">
    <meta name="author" content="">
    <meta property="article:published_time"
        content="<?=date("Y-m-d\TH:i:s.000\Z", strtotime($PostDetails->PublishedTime));?>" />

    <meta property="og:locale" content="en_US">
    <link rel="canonical" href="<?=base_url($PostDetails->PostSlug);?>" />


    <meta content="<?=date("Y-m-d\TH:i:s.000\Z", strtotime($PostDetails->ModifiedTime));?>"
        property="article:modified_time" />
    <meta content="<?=date("Y-m-d\TH:i:s.000\Z", strtotime($PostDetails->PublishedTime));?>"
        property="article:published_time" />


    <?php
} else {
    ?>
    <link rel="canonical" href="<?=base_url();?>" />
    <?php }?>

    <!--AD Body Start-->
    <?=$settings->InPageAds;?>
    <!--AD Body End-->
    <style>
    <?=$settings->CustomCss;
    ?>
    </style>
    <!-- end head -->
</head>

<body>
    <div class="n-layout">
        <div class="n-layout__row n-layout__row--header">

            <header id="site-navigation" class="o-header o-header--large-logo" data-o-component="o-header"
                data-o-header--no-js="true" tabindex="-1">
                <div class="o-header__row o-header__top" data-trackable="header-top">
                    <div class="o-header__container">
                        <div class="o-header__top-wrapper">
                            <div class="o-header__top-column o-header__top-column--left"><a href="#o-header-drawer"
                                    class="o-header__top-icon-link o-header__top-icon-link--menu"
                                    aria-controls="o-header-drawer" title="Open side navigation menu"
                                    data-trackable="drawer-toggle"><span class="o-header__top-link-label">Open side
                                        navigation menu</span></a></div>
                            <div class="o-header__top-column o-header__top-column--center"><a class="o-header__top-logo"
                                    style="background-image:none;text-align:center;" data-trackable="logo"
                                    href="<?= site_url();?>"
                                    title="Go to Financial Times homepage"><?php if ($settings->SiteLogo): ?>

                                    <img class="jl_logo_n" src="<?=$settings->SiteLogo;?>"
                                        alt="<?=$settings->SiteTitle;?>">


                                    <?php else: ?>
                                    <span><?=$settings->SiteTitle;?></span>
                                    <?php endif;?></a></div>
                            <div class="o-header__top-column o-header__top-column--right">
                                <a href="#o-header-search-primary"
                                    class="o-header__top-icon-link o-header__top-icon-link--search"
                                    aria-controls="o-header-search-primary" title="Open search bar"
                                    data-trackable="search-toggle"><span class="o-header__top-link-label">Open search
                                        bar</span></a>
                                <!-- <a
                                    class="o-header__top-button o-header__top-button--hide-m" role="button"
                                    href="/products?segmentId=f860e6c2-18af-ab30-cd5e-6e3a456f9265"
                                    data-trackable="Subscribe">Subscribe</a><a
                                    class="o-header__top-link o-header__top-link--hide-m" href="/login?location=/"
                                    data-trackable="Sign In">Sign In</a><a
                                    class="o-header__top-icon-link o-header__top-icon-link--myft o-header__top-icon-link--show-m"
                                    id="o-header-top-link-myft" href="/myft" data-trackable="my-ft"
                                    data-tour-stage="myFt" aria-label="My F T"><span
                                        class="o-header__visually-hidden">myFT</span></a> -->
                            </div>
                        </div>
                    </div>
                </div>
                <div id="o-header-search-primary" class="o-header__row o-header__search o-header__search--primary"
                    data-trackable="header-search" data-o-header-search="true">
                    <div class="o-header__container">
                        <form class="o-header__search-form" action="<?=base_url('search')?>" role="search"
                            aria-label="Site search" data-n-topic-search="true"
                            data-n-topic-search-categories="concepts,equities" data-n-topic-search-view-all="true">
                            <label class="o-header__visually-hidden" for="o-header-search-term-primary">Search the <abbr
                                    title="Financial Times">FT</abbr></label><input type="text"
                                class="o-header__search-term" id="o-header-search-term-primary"
                                value="<?php echo isset($_GET['q']) ? $_GET['q'] : ''; ?>" name="q" autocomplete="off"
                                autocorrect="off" autocapitalize="off" spellcheck="false" data-trackable="search-term"
                                placeholder="Search..." data-n-topic-search-input="true"><button
                                class="o-header__search-submit" type="submit"
                                data-trackable="search-submit">Search</button><button
                                class="o-header__search-close o--if-js" type="button"
                                aria-controls="o-header-search-primary" title="Close search bar"
                                data-trackable="close"><span class="o-header__visually-hidden">Close search
                                    bar</span></button>
                        </form>
                    </div>
                </div>
                <nav id="o-header-nav-mobile" class="o-header__row o-header__nav o-header__nav--mobile"
                    aria-hidden="true" data-trackable="header-nav:mobile">
                    <ul class="o-header__nav-list">
                        <li class="o-header__nav-item"><a class="o-header__nav-link o-header__nav-link--primary"
                                href="<?= site_url()?>" aria-label="Home, current page" aria-current="page"
                                data-trackable="Home">Home</a></li>
                        <li class="o-header__nav-item"><a class="o-header__nav-link o-header__nav-link--primary"
                                href="https://markets.ft.com/data" data-trackable="Markets Data">Markets Data</a></li>
                    </ul>
                </nav>
                <nav id="o-header-nav-desktop" class="o-header__row o-header__nav o-header__nav--desktop"
                    role="navigation" aria-label="Primary navigation" data-trackable="header-nav:desktop">
                    <div class="o-header__container">
                        <ul class="o-header__nav-list o-header__nav-list--left" data-trackable="primary-nav">
                            <li class="o-header__nav-item"><a class="o-header__nav-link o-header__nav-link--primary"
                                    href="<?= site_url()?>" id="o-header-link-0" aria-label="Home, current page"
                                    aria-current="page" data-trackable="Home">Home</a></li>
                            <?php foreach (array_slice($categories, 0, 6) as $key => $value): ?>
                            <li class="o-header__nav-item"><a class="o-header__nav-link o-header__nav-link--primary"
                                    href="<?=base_url('category/' . $value['TermSlug'])?>" id="o-header-link-4"
                                    data-trackable="<?=$value['TermName']?>"><?=$value['TermName']?></a></li>
                            <?php endforeach;?>
                            <?php if (count($categories) > 6): ?>
                            <li class="o-header__nav-item"><a class="o-header__nav-link o-header__nav-link--primary"
                                    href="javascript:void(0)" id="o-header-link-1">More Items</a>
                                <div class="o-header__mega" id="o-header-mega-1" role="group"
                                    aria-labelledby="o-header-link-1" data-o-header-mega="true"
                                    data-trackable="meganav | World" aria-hidden="true" aria-expanded="false">
                                    <div class="o-header__container">
                                        <div class="o-header__mega-wrapper">



                                            <div class="o-header__mega-column o-header__mega-column--subsections"
                                                data-trackable="sections">

                                                <div class="o-header__mega-content">
                                                    <ul class="o-header__mega-list">
                                                        <?php foreach (array_slice($categories,6) as $key => $value): ?>
                                                        <li class="o-header__mega-item"><a class="o-header__mega-link"
                                                                href="<?=base_url('category/' . $value['TermSlug'])?>"
                                                                data-trackable="link"><?=$value['TermName']?></a></li>

                                                        <?php endforeach;?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="o-header__mega-column o-header__mega-column--articles"
                                                data-trackable="popular">
                                                <div class="o-header__mega-heading">Most Read</div>
                                                <div class="o-header__mega-content">
                                                    <ul class="o-header__mega-list">
                                                        <li class="o-header__mega-item"><a class="o-header__mega-link"
                                                                href="javascript:void(0)" data-trackable="link">Russia
                                                                starts partial
                                                                evacuation from southern Ukraine</a></li>
                                                        <li class="o-header__mega-item"><a class="o-header__mega-link"
                                                                href="javascript:void(0)" data-trackable="link">Yellen
                                                                warns of
                                                                ‘constitutional crisis’ over US debt ceiling
                                                                impasse </a></li>
                                                        <li class="o-header__mega-item"><a class="o-header__mega-link"
                                                                href="javascript:void(0)" data-trackable="link">Saudi
                                                                Arabia’s journey
                                                                from troublemaker to diplomat</a></li>
                                                        <li class="o-header__mega-item"><a class="o-header__mega-link"
                                                                href="javascript:void(0)" data-trackable="link">US debt
                                                                ceiling debacle
                                                                adds to economists’ fears of turmoil</a></li>
                                                        <li class="o-header__mega-item"><a class="o-header__mega-link"
                                                                href="javascript:void(0)" data-trackable="link">China
                                                                holds security and
                                                                trade talks with Taliban</a></li>
                                                    </ul>
                                                </div>
                                            </div>




                                        </div>
                                    </div>
                                </div>
                            </li>
                            <?php endif;?>


                        </ul>
                    </div>
                </nav>
            </header>
            <header class="o-header o-header--simple o-header--sticky o--if-js" data-o-component="o-header"
                data-o-header--sticky="true" aria-hidden="true">
                <div class="o-header__row o-header__top" data-trackable="header-sticky">
                    <div class="o-header__container">
                        <div class="o-header__top-wrapper">
                            <div class="o-header__top-column o-header__top-column--left"><a href="#"
                                    class="o-header__top-icon-link o-header__top-icon-link--menu"
                                    aria-controls="o-header-drawer" data-trackable="drawer-toggle" tabindex="-1"><span
                                        class="o-header__top-link-label">Menu</span></a><a href="#"
                                    class="o-header__top-icon-link o-header__top-icon-link--search"
                                    aria-controls="o-header-search-sticky" data-trackable="search-toggle"
                                    tabindex="-1"><span class="o-header__top-link-label">Search</span></a></div>
                            <div class="o-header__top-column o-header__top-column--center">
                                <div class="o-header__top-takeover">
                                    <div class="o-header__nav">
                                        <ul class="o-header__nav-list o-header__nav-list--left"
                                            data-trackable="primary-nav">
                                            <li class="o-header__nav-item"><a
                                                    class="o-header__nav-link o-header__nav-link--primary"
                                                    href="<?= site_url()?>" data-trackable="Home" tabindex="-1">Home</a>
                                            </li>
                                            <?php foreach ($categories as $key => $value): ?>
                                            <li class="o-header__nav-item"><a
                                                    class="o-header__nav-link o-header__nav-link--primary"
                                                    href="<?=base_url('category/' . $value['TermSlug'])?>"
                                                    data-trackable="<?=$value['TermName']?>"
                                                    tabindex="-1"><?=$value['TermName']?></a></li>
                                            <?php endforeach;?>


                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div id="o-header-search-sticky" class="o-header__row o-header__search o-header__search--sticky"
                    data-trackable="header-search" data-o-header-search="true">
                    <div class="o-header__container">
                        <form class="o-header__search-form" action="<?=base_url('search')?>" role="search"
                            aria-label="Site search" data-n-topic-search="true"
                            data-n-topic-search-categories="concepts,equities" data-n-topic-search-view-all="true">
                            <label class="o-header__visually-hidden" for="o-header-search-term-sticky">Search the <abbr
                                    title="Search "></abbr></label><input type="text" class="o-header__search-term"
                                id="o-header-search-term-sticky"
                                value="<?php echo isset($_GET['q']) ? $_GET['q'] : ''; ?>" name="q" autocomplete="off"
                                autocorrect="off" autocapitalize="off" spellcheck="false" data-trackable="search-term"
                                placeholder="search ..." data-n-topic-search-input="true"><button
                                class="o-header__search-submit" type="submit"
                                data-trackable="search-submit">Search</button><button
                                class="o-header__search-close o--if-js" type="button"
                                aria-controls="o-header-search-sticky" title="Close search bar"
                                data-trackable="close"><span class="o-header__visually-hidden">Close search
                                    bar</span></button>
                        </form>
                    </div>
                </div>
            </header>
        </div>