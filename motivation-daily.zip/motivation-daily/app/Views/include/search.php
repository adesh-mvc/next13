<section>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <aside class="wrapper__list__article ">
                    <h4 class="border_section">
                        Search results for keyword: <span class="text-primary"> <?php echo $_GET['q']; ?> </span>
                    </h4>

                    <!-- Post Article List -->
                    <?php if ($search): ?>

                    <?php foreach ($search as $key => $value):

    $CategoryName = $categories[$value->CatId]['TermName'];
    $CategorySlug = base_url('category/' . $categories[$value->CatId]['TermSlug']);
    $slug = base_url($value->PostSlug);
    $title = strlen($value->PostTitle) > 40 ? implode(' ', array_slice(explode(' ', strip_tags($value->PostTitle)), 0, 10)) . "..." : $value->PostTitle;
    $thumb_url = $value->PostThumbUrl;
    $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 40));
    ?>
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row bg-light">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="<?=$slug?>">
                                        <img data-src="<?=$thumb_url?>" class="img-fluid w-100 lazy" alt="<?=$title?>">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            <?=$CategoryName?>
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">

                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        <?=date('F d, Y', strtotime($value->Date));?>
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="<?=$slug?>">
                                                    <?=$title?>
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                <?=$content?>
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <?php endforeach;?>

                    <?php else: ?>
                    <nav class="jellywp_pagination" style="background:#ff4200">
                        <div class="page-numbers">
                            <span aria-current="page" class="page-numbers current">No Post Found</span>

                        </div>
                    </nav>
                    <?php endif?>

                </aside>
            </div>
            <div class="col-md-4">
                <?=$this->include('include/sidebar')?>
            </div>
        </div>
    </div>
</section>