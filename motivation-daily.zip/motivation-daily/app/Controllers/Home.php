<?php

namespace App\Controllers;

use App\Models\CommonModel;

class Home extends BaseController
{
    public function __construct()
    {
        $this->model = new CommonModel();

        $this->CategoryItems = 10;
    }

    public function index()
    {
        $data = [];

        $data['controller'] = $this;

        $data['featured'] = $this->posts($offset = 0, $limit = 15);

        return $this->render_page('home', $data);

    }

    public function posts($offset = 0, $limit = 5, $fields = [], $condition = [])
    {

        return $this->model->getPosts($offset, $limit, $fields, $condition);
    }

    //for category
    public function category($slug, $page = '', $perpage = '')
    {

        $data = [];

        $data['controller'] = $this;

        //load if slider or fetured available in category
        //$data['featured'] = $this->posts();

        $categories = $this->model->getCateogry();
        $categoryId = $this->multi_in_array($slug, $categories, "TermSlug");

        $data['CatId'] = $categoryId;
        // $data['PerPage']=$perpage;
        // $data['CatSlug']='category/'.$slug;
        $data['CatSlug'] = 'category/' . $slug;
        $data['page'] = $perpage ? $perpage : 1;
        $data['PerPage'] = $perpage;

        if ($perpage) {
            $data['show_limit'] = $this->CategoryItems * $perpage;
        } else {
            $data['show_limit'] = $this->CategoryItems;
        }
        return $this->render_page('category', $data);

    }
    public function paginationCategory($page)
    {
        $slugTail = service('uri')->getSegments();
        $pageNo = $page - 1;
        $offset = $pageNo ? $pageNo * $this->CategoryItems : 0;

        $posts = $this->posts($offset, $this->CategoryItems, $fields = ['PostContent'], $condition = ['CatId' => end($slugTail)]);

        if (is_countable($posts) && count($posts)) {

            foreach ($posts as $key => $value):
                shuffle($this->color);
                $title = strlen($value->PostTitle) > 40 ? substr($value->PostTitle, 0, 40) . "..." : $value->PostTitle;
                $slug = base_url($value->PostSlug);

                $CategoryName = $this->categories[end($slugTail)]['TermName'];
                $CategorySlug = base_url('category/' . $this->categories[end($slugTail)]['TermSlug']);
                //$title = $value->PostTitle;
                $slug = base_url($value->PostSlug);

                $content = implode(' ', array_slice(explode(' ', strip_tags($value->PostContent)), 0, 30));
                $thumb_url = $value->PostThumbUrl
                ?>
<div class="col-md-6 bg-light">
    <!-- Post Article -->
    <div class="article__entry">
        <div class="article__image">
            <a href="<?=$slug?>">
                <img src="<?=$thumb_url?>" alt="<?=$title?>" class="img-fluid">
            </a>
        </div>
        <div class="article__content">
            <div class="article__category">
                <?=$CategoryName?> </div>
            <ul class="list-inline">

                <li class="list-inline-item">
                    <span class="text-dark text-capitalize">
                        <?=date('F d, Y', strtotime($value->Date));?>
                    </span>
                </li>

            </ul>
            <h5>
                <a href="<?=$slug?>">
                    <?=$title?>
                </a>
            </h5>
            <p>
                <?=$content?>
            </p>
            <a href="<?=$slug?>" class="btn btn-outline-primary mb-4 text-capitalize"> read
                more</a>
        </div>
    </div>


</div>
<?php endforeach;
        } else {
            echo 'finished';
        }
    }
    //for article page
    public function article($category, $slug)
    {

        $data = [];
        /**Tracking Code Start**/

        $myString = $_SERVER['REQUEST_URI'];

        /**Tracking Code End**/
        $data['article_ads'] = new \App\Libraries\ArticleAds;
        $data['controller'] = $this;
        $categories = $this->model->getCateogry();
        $categoryId = $this->multi_in_array($category, $categories, "TermSlug");
        $data['CatId'] = $categoryId;

        $PostSlug = $category . '/' . $slug;
        $IsWhere = array('PostSlug' => $PostSlug);

        $data['CatSlug'] = 'category/' . $category;
        $PostDetails = $this->posts(0, 1, array('PostContent', 'p.ID'), $IsWhere);
        // print_r($this->model->getPrevious($PostDetails[0]->ID)); die;
        $data['next_blog'] = $this->model->getNext($PostDetails[0]->ID);
        $data['prev_blog'] = $this->model->getPrevious($PostDetails[0]->ID);
        if (!empty($PostDetails)) {
            $data['PostDetails'] = $PostDetails[0];
        } else {
            return view('errors/404');
        }

        return $this->render_page('post-detail', $data);

    }

    public function page($slug)
    {
        $data = [];
        $data['controller'] = $this;
        $Condition = array('PageSlug' => $slug);
        $PageDetails = $this->model->getPage($Condition);
        if (!empty($PageDetails)) {
            $data['PostDetails'] = $PageDetails[0];
        } else {
            return view('errors/404');
        }
        return $this->render_page('page', $data);

    }

    public function multi_in_array($needle, $haystack, $key)
    {
        //no need to run query to get category id , Find and return in existing data
        foreach ($haystack as $parent => $h) {
            if (array_key_exists($key, $h) && $h[$key] == $needle) {
                return $parent;
            }
        }
        return false;
    }

    public function create_html($html, $ADS1, $ADS2)
    {

        $dom = new \DOMDocument();

        $dom->loadHtml('
  <html><head></head>
    <body>
      <div id="content">
        ' . $html . '

      </div>
    </body>
  </html>
');

//find the "content" div
        $content = $dom->getElementById('content');

//find the first h3 tag in "content"

        $x = 1;

        do {
            $origH3 = $content->getElementsByTagName('h' . $x)->item(0);
            if (!empty($origH3)) {
                break;
            }
            $x++;
        } while ($x <= 5);

        if (empty($origH3)) {
            $origH3 = $content->getElementsByTagName('img')->item(0);
        }

        $x = 1;

        do {
            $origH4 = $content->getElementsByTagName('h' . $x)->item(2);
            if (!empty($origH4)) {
                break;
            }
            $x++;
        } while ($x <= 5);

        if (empty($origH4)) {
            $origH4 = $content->getElementsByTagName('img')->item(2);
        }

//create a new h3
        $newH3 = $dom->createElement('div', $ADS1);

        $newH4 = $dom->createElement('div', $ADS2);

//insert the new h3 before the original h3 of "content"
//insert the new h3 before the original h3 of "content"
//if(!empty($origH3) && $origH3->childElementCount > 0 ){
        $content->insertBefore($newH3, $origH3);
//}
//if(!empty($origH4) && $origH4->childElementCount > 0){
        $content->insertBefore($newH4, $origH4);
//}
        return $dom->saveHTML();

    }

    public function search()
    {
        $data = [];
        $data['controller'] = $this;
        if ($_GET['q']) {
            $sea = $_GET['q'];
            $sea = str_replace('+', ' ', $sea);
        } else {
            $sea = '';
        }
        $data['search'] = $this->model->getAllPosts($sea);

        return $this->render_page('include/search', $data);
    }

}