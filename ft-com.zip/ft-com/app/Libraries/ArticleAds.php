<?php 
namespace App\Libraries;
class ArticleAds{
    function create_html($html,$ADS1,$ADS2){

        $dom = new \DOMDocument();        
        $internalErrors = libxml_use_internal_errors(true);
        $dom->loadHtml('
          <html><head></head>
            <body>
              <div id="content">
              '.$html.'
              </div>
            </body>
          </html>
        ');
        libxml_use_internal_errors($internalErrors);

        //find the "content" div
        $content = $dom->getElementById('content');
        
        //find the first h3 tag in "content"
        
         //create a new h3
         $newH3 = $dom->createElement('div', $ADS1);
        
         $newH4 = $dom->createElement('div', $ADS2);
     
         $totalItems = $dom->getElementsByTagName('*');
         $tag = array('img','h1','h2','h3','h4');
         $tag_array=[];
         foreach($totalItems as $k => $element ){
          if($k > 2){
          $tag_array[$element->tagName][] =  $element;
          }
         }
           $tag_stack_size = [];
          $tagItems = $tag_array;
          foreach($tag_array as $k=>$tags){
            $tag_stack_size[$k] = count($tags);
          }
        $result_array = array_intersect_key($tag_stack_size,array_flip($tag));
        if(count($result_array)){
            foreach($result_array as $key=>$occurances){
                  
              if(isset($tagItems[$key])){
                $ads1index = $occurances>3? 1:0;
                $ads2index = $occurances>3? $occurances - 2:3;
                // echo $key."\n"; 
                $existingTag_Ads_1 = $content->getElementsByTagName($key)->item(0); 
                $existingTag_Ads_2 = $content->getElementsByTagName($key)->item(3);
                if(in_array($key,array('img','h1','h2','h3','h4','h5','h6','p','iframe'))){                     
                  if(isset($existingTag_Ads_1->childElementCount) && $existingTag_Ads_1->childElementCount > 0 && isset($existingTag_Ads_2->childElementCount) && $existingTag_Ads_2->childElementCount > 0){  
                      $ads_1 = $existingTag_Ads_1->nextSibling;
                      $ads_1->nextSibling->appendChild($newH3);
                      if(isset($existingTag_Ads_2->nextSibling)){
                      $ads_2 = $existingTag_Ads_2->nextSibling;              
                    $ads_2->nextSibling->appendChild($newH4);
                      }              
                  }else if(isset($existingTag_Ads_1->childElementCount) && $existingTag_Ads_1->childElementCount > 0){
                    $ads_1 = $existingTag_Ads_1->nextSibling;
                    $ads_1->nextSibling->appendChild($newH3);
                    if(isset($existingTag_Ads_2->parentNode))
                    $existingTag_Ads_2->parentNode->insertBefore($newH4, $existingTag_Ads_2);
                  }else{           
                    if(isset($existingTag_Ads_1->parentNode) && isset($existingTag_Ads_2->parentNode)){
                      $existingTag_Ads_1->parentNode->insertBefore($newH3, $existingTag_Ads_1);
                      $existingTag_Ads_2->parentNode->insertBefore($newH4, $existingTag_Ads_2);
                    }else if(isset($existingTag_Ads_1->parentNode)){
                      $existingTag_Ads_1->parentNode->insertBefore($newH3, $existingTag_Ads_1);
                      $content->insertBefore($newH4, $existingTag_Ads_2);
                    }else{                
                      $content->insertBefore($newH3, $existingTag_Ads_1);
                      $content->insertBefore($newH4, $existingTag_Ads_2);
                    }                   
                  }         
                  break;
                }else if(in_array($key,array('figure','strong'))){  
                  if($existingTag_Ads_1->childElementCount){
                    $ads_1 = $existingTag_Ads_1->nextSibling;
                    $ads_1->nextSibling->appendChild($newH3);
                    $ads_2 = $existingTag_Ads_2->nextSibling;
                    $ads_2->nextSibling->appendChild($newH4);
                  
                  }else{
                  //  $existingTag_Ads_1->parentNode->insertBefore($newH3, $existingTag_Ads_1);
                  $content->insertBefore($newH3, $existingTag_Ads_1);
                  $content->insertBefore($newH4, $existingTag_Ads_2);  
                  }
                
                  break;
                }
              }
          
            }
          }
      
      return $dom->saveHTML();
        
        
         }
}
?>