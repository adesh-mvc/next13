<style>
.loader {
  border: 2px solid #f3f3f3;
  border-radius: 50%;
  border-top: 2px solid #000000;
  width: 20px;
  height: 20px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
<link rel="stylesheet" id="elementor-frontend-css" href="https://www.fashionsootra.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.0.12" type="text/css" media="all">
<div class="g1-row-inner" >
   <!--AD Body Start-->
	                   <?=$settings->HeaderAds;?>
   <!--AD Body End-->
</div>
<div class="g1-primary-max">
   <div id="content" role="main">
      <article id="post-3873" class="post-3873 page type-page status-publish" itemscope=""
         itemtype="http://schema.org/WebPage">
         <header class="page-header page-header-01 g1-row g1-row-layout-page">
            <div class="g1-row-inner">
               <div class="g1-column">
                  <nav class="g1-breadcrumbs g1-breadcrumbs-with-ellipsis g1-meta">
                     <p class="g1-breadcrumbs-label">You are here: </p>
                     <ol itemscope itemtype="http://schema.org/BreadcrumbList">
                        <li class="g1-breadcrumbs-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                           <a itemprop="item" content="<?=base_url();?>" href="<?=base_url();?>">
                              <span itemprop="name">Home</span>
                              <meta itemprop="position" content="1" />
                           </a>
                        </li>
                        <li class="g1-breadcrumbs-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                           <span itemprop="name"></span>
                           <meta itemprop="position" content="2" />
                           <meta itemprop="item" content="" />
                        </li>
                     </ol>
                  </nav>
               </div>
            </div>
            <div class="g1-row-background">
            </div>
         </header>
         <div class="page-body g1-row g1-row-layout-page g1-row-padding-m">
            <div class="g1-row-background">
            </div>
            <div class="g1-row-inner">
               <div id="primary" class="g1-column">
                  <div class="entry-content" itemprop="text" >
                     <div data-elementor-type="wp-post" data-elementor-id="3873" class="elementor elementor-3873" data-elementor-settings="[]">
                        <div class="elementor-inner">
                           <div class="elementor-section-wrap">
                              <section class="elementor-section elementor-top-section elementor-element elementor-element-2f8257d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2f8257d" data-element_type="section">
                                 <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                       <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b5fe35b" data-id="b5fe35b" data-element_type="column">
                                          <div class="elementor-column-wrap elementor-element-populated">
                                             <div class="elementor-widget-wrap">
                                                <h1 class="g1-alpha g1-alpha-2nd page-title"><?php echo ucwords('Latest trends in shopping');?></h1>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
<!--AMAZON START-->


<style>
* {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 30.33%;
  padding: 10px;
  margin-left:10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
.columns {
    float: left;
    width: 15%;
    padding: 25px;
    margin-left: 10px;
    height: 300px; 
    margin-top: 10px;
    box-shadow: 1px 5px;
    border: 1px solid;
}
.amazon.amzn-ad-container{
	width: 144px !important;
}
.parent.row{
	margin-bottom: 20px;
}
@media screen and (max-width: 600px) {
  .columns {
    width: 46%;
    padding: 10px;
  }
}


</style>
	<div id="products-all">
	<?php
	$i=0;
	$IsNumber=0;
	$tag = $_GET['tag'];
	foreach ($products as $key => $value):
	$i++;
        $IsNumber++;
	$AffCode=$value->AffCode;
	if(!empty($tag)){
		$AffCode=str_replace("fashionsootra-21", $tag,$value->AffCode);
	}else{
		$AffCode=$value->AffCode;
	}
	if($i%3==0){
		$AffCode =  str_replace("ffffff", 'ff0036',$AffCode);
		$AffCode =  str_replace("0066c0", 'ffffff',$AffCode);
		$AffCode =  str_replace("333333", 'ffffff',$AffCode);
	}else{
		$AffCode =  str_replace("0066c0", '000000',$AffCode);
		$AffCode =  str_replace("333333", '000000',$AffCode);
	}
	if($i%6==0){
	
	?>
	<div class="row parent">
	<?php } ?>
	<div class="columns">
	
		<?=$AffCode;?>
	</div>
	<?php
	if($i%6==0){
	?>
	</div>  
	<?php } ?>  
	<?php endforeach ?>
	<div class="row">
	</div>
	
<!--AMAZON END-->
          			<section class="elementor-section elementor-top-section elementor-element elementor-element-931c4be elementor-section-boxed elementor-section-height-default elementor-section-height-default" id="below-section" data-id="931c4be" data-element_type="section">
                                 <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                       <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a9e44a8" data-id="a9e44a8" data-element_type="column">
                                          <div class="elementor-column-wrap">
                                             <div class="elementor-widget-wrap">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- .entry-content -->
               </div>
             
            </div>
         </div>
      </article>
      <!-- #post-## -->
   </div>
   <!-- #content -->

</div>
<!-- #primary -->

   		<div class="g1-collection-more infinite-scroll on-demand" style="display:block;margin-top: 30px;">
                     <div class="g1-collection-more-inner">
			<?php 
				 $nextPage = ($PerPage)? $PerPage+=1 : 2;
				 
				 if($IsNumber < 12 ){ $style='opacity: 0.6;  pointer-events: none';$html='<p id="post-status">You have reached the end.</p>';}else{$style="";$html='';}
				  echo '<p id="loadmore_msg">'.$html.'</p>';
			?>

                        <a href="javascript:void(0)" class="g1-button g1-button-m g1-button-solid " style="<?=$style;?>" id="loadItems">
                        Load More			</a>

			<div id="g1-collection-more-spinner"></div>
                        <input type="hidden" id="nextPage" value="<?=$nextPage?>">
                     </div>
                  </div>
<script>
const loadButton = document.getElementById('loadItems');

loadButton.addEventListener('click',function(e){

document.getElementById("g1-collection-more-spinner").classList.add("loader");

var pageElem = document.getElementById('nextPage');
var page = pageElem.value;

   e.preventDefault();

   var tag =  "<?php echo $_GET['tag'];?>";

   if(tag){
	var reqUrl = `/shop/add/${page}?tag=`+tag;
   }else{
	var reqUrl = `/shop/add/${page}`;
   }

   var xhr = new XMLHttpRequest();
   xhr.open('GET',reqUrl,true);
   xhr.onload = function () {
    if (xhr.readyState === xhr.DONE) {
        if (xhr.status === 200) {
		document.getElementById("g1-collection-more-spinner").classList.remove("loader");
	   if(xhr.response){
	   	
	   	pageElem.value = parseInt(page)+1; 
           	document.getElementById('products-all').insertAdjacentHTML('beforeend', xhr.response);
		 if(tag){
			var reqUrlState = `/shop/page/${page}?tag=`+tag;
   		}else{
			var reqUrlState = `/shop/page/${page}`;
   		}

           	history.pushState('/shop', "Title", reqUrlState);
	   }else{
		document.getElementById('loadmore_msg').innerHTML='You have reached the end';
		loadButton.style.opacity = "0.6";

	   }
        }
    }
};
   xhr.send();
   console.log(xhr)
})
</script>