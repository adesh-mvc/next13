<?php

namespace App\Controllers;
use App\Models\CommonModel;

class Shop extends BaseController
{
     public function __construct()
    {
        $this->model = new CommonModel();
	$this->limit = 12;
        
    }

    public function index($page='',$PerPage=1)
    {
	
	$IsLink=$_GET['linkid'];
	$IsSkuId=$IsLink;
	$IsTag = $_GET['tag'];
	$IsKey =$_GET['keywords'];
	if(!empty($IsTag)){
		$tag = $IsTag;
	}else{
		$tag = 'fashionsootra-21';
	}
	if(!empty($IsKey)){
		$keywords = '&keywords='.$IsKey;
		$keywords = str_replace('+',' ',$keywords);
	}else{
		$keywords='';
	}


	$IsLinkUrl="https://www.amazon.in/dp/".$IsSkuId."?ref=as_sl_pc_tf_til&tag=".$tag."&linkCode=w00&linkId=&creativeASIN=".$IsSkuId.$keywords;
	if(!empty($IsSkuId)){
		echo '<script>window.location.href="'.$IsLinkUrl.'"</script>';die;
		//header("Location:".$IsLinkUrl);die;
	}


        $data=[];
	//$offset=($PerPage && $PerPage > 1 )? ($PerPage-1)*(12) : 0;
	$offset= 0;
	$limit=$PerPage*12;
	
	
        $data['controller'] = $this;
        $data['PerPage']=$PerPage;
        $data['products'] = $this->model->getAmazonProduct($offset,$limit);
        return $this->render_page('amazon',$data);
     
    }
    
    function paginationData(){
        $uri = service('uri');
         $pageNo = $uri->getSegment(3) -1;
	 $IsTag = $_GET['tag'];
	 if(!empty($IsTag)){
		$data['tag'] = $IsTag;
	  }
          $offset = $pageNo?$pageNo * $this->limit:0;
         $data['products']= $this->model->getAmazonProduct($offset,$this->limit);
        //print_r(count($data));
        return view('amazon_ajax',$data);
        //exit;

    }


}