<!--AD Body Start-->
<?php if (!empty($_GET['static'])) {?>
<div id="advertize_content2"> Advertize Content Two
    <?=$settings->FooterAds;?>
</div>
<?php } else {?>
<?=$settings->FooterAds;?>
<?php }?>
<!--AD Body End-->
<section class="wrapper__section p-0">
    <div class="wrapper__section__components">
        <!-- Footer -->
        <footer>
            <div class="wrapper__footer bg-white">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="wrapper__footer-logo text-center">
                                <a href="<?=base_url()?>">
                                    <figure class="mb-4">


                                        <?php if ($settings->SiteLogo): ?>
                                        <img class="img-fluid logo-footer" src="<?=$settings->SiteLogo;?>"
                                            alt="<?=$settings->SiteTitle;?>">
                                        <?php else: ?>
                                        <span><?=$settings->SiteTitle;?></span>
                                        <?php endif;?>

                                    </figure>
                                </a>

                                <p>
                                    <?=$settings->footerAbout;?>
                                </p>
                                <p class="mb-0">
                                    <button class="btn btn-social btn-social-o facebook mr-1">
                                        <i class="fa fa-facebook-f"></i>
                                    </button>
                                    <button class="btn btn-social btn-social-o twitter mr-1">
                                        <i class="fa fa-twitter"></i>
                                    </button>

                                    <button class="btn btn-social btn-social-o linkedin mr-1">
                                        <i class="fa fa-linkedin"></i>
                                    </button>
                                    <button class="btn btn-social btn-social-o instagram mr-1">
                                        <i class="fa fa-instagram"></i>
                                    </button>

                                    <button class="btn btn-social btn-social-o youtube mr-1">
                                        <i class="fa fa-youtube"></i>
                                    </button>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer bottom -->
            <div class="bg__footer-bottom bg-light">
                <div class="container">
                    <div class="row flex-column-reverse flex-md-row">
                        <div class="col-md-6">
                            <span class="text-dark">
                                © Copyright <?=date('Y');?>
                                <?=$settings->CopyRight;?>
                                All Rights Reserved.
                            </span>
                        </div>
                        <div class="col-md-6">
                            <ul class="list-inline ">
                                <li class="list-inline-item">
                                    <a href="<?=base_url();?>" class="text-dark ">
                                        Home
                                    </a>
                                </li>
                                <?php foreach ($pages as $key => $value): ?>
                                <li class="list-inline-item">
                                    <a href="<?=base_url($value->PageSlug);?>" class="text-dark ">
                                        <?=$value->PageTitle;?>
                                    </a>
                                </li>
                                <?php endforeach;?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>


    </div>
</section>


<a href="javascript:" id="return-to-top"><i class="fa fa-chevron-up"></i></a>

<script src="<?=base_url('assets')?>/js/index.bundle3875.js?1fcca2a2c42e9d47a3eb"></script>
<script src="<?=base_url('assets')?>/js/lazyload.min.js"></script>
<script src="<?=base_url('assets')?>/js/lazyinit.js"></script>
</body>


<?php /*
$_SERVERHOST = preg_replace('/^www\./i', '',$_SERVER['SERVER_NAME']);
include('/var/www/html/'.$_SERVERHOST.'/get_file.php'); */
?>

</html>