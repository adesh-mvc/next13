<?php
?>
<link rel="stylesheet" id="elementor-frontend-css" href="https://www.fashionsootra.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.0.12" type="text/css" media="all">
<div class="g1-row-inner" >
   <!--AD Body Start-->
	                   <?=$settings->HeaderAds;?>
   <!--AD Body End-->
</div>
<div class="g1-primary-max">
   <div id="content" role="main">
      <article id="post-3873" class="post-3873 page type-page status-publish" itemscope=""
         itemtype="http://schema.org/WebPage">
         <header class="page-header page-header-01 g1-row g1-row-layout-page">
            <div class="g1-row-inner">
               <div class="g1-column">
                  <nav class="g1-breadcrumbs g1-breadcrumbs-with-ellipsis g1-meta">
                     <p class="g1-breadcrumbs-label">You are here: </p>
                     <ol itemscope itemtype="http://schema.org/BreadcrumbList">
                        <li class="g1-breadcrumbs-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                           <a itemprop="item" content="<?=base_url();?>" href="<?=base_url();?>">
                              <span itemprop="name">Home</span>
                              <meta itemprop="position" content="1" />
                           </a>
                        </li>
                        <li class="g1-breadcrumbs-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                           <span itemprop="name"></span>
                           <meta itemprop="position" content="2" />
                           <meta itemprop="item" content="" />
                        </li>
                     </ol>
                  </nav>
               </div>
            </div>
            <div class="g1-row-background">
            </div>
         </header>
         <div class="page-body g1-row g1-row-layout-page g1-row-padding-m">
            <div class="g1-row-background">
            </div>
            <div class="g1-row-inner">
               <div id="primary" class="g1-column g1-column-2of3">
                  <div class="entry-content" itemprop="text" >
                     <div data-elementor-type="wp-post" data-elementor-id="3873" class="elementor elementor-3873" data-elementor-settings="[]">
                        <div class="elementor-inner">
                           <div class="elementor-section-wrap">
                              <section class="elementor-section elementor-top-section elementor-element elementor-element-2f8257d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2f8257d" data-element_type="section">
                                 <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                       <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b5fe35b" data-id="b5fe35b" data-element_type="column">
                                          <div class="elementor-column-wrap elementor-element-populated">
                                             <div class="elementor-widget-wrap">
                                                <h1 class="g1-alpha g1-alpha-2nd page-title">Shop</h1>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
<!--AMAZON START-->


<style>
* {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 30.33%;
  padding: 10px;
margin-left:10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 45%;
  }
}
</style>
</head>
<body>
   
	<?php
	$i=0;
	foreach ($products as $key => $value):
	$i++;
	if($i%3==0){
	?>
	<div class="row">
	<?php } ?>
	<div class="column">
		<?=$value->AffCode;?>
	</div>
	<?php
	if($i%3==0){
	?>
	</div>  
	<?php } ?>  
	<?php endforeach ?>


<hr>

<div class="OUTBRAIN" data-ob-contentUrl="" data-widget-id="AR_1" data-ob-installation-key="FUTUR2LJF6EDI45D3H679DA9H"></div> <script type="text/javascript" async="async" src="https://widgets.outbrain.com/outbrain.js"></script> <script> document.getElementsByClassName('OUTBRAIN')[0].setAttribute('data-ob-contenturl',window.location.href) </script>   
<!--AMAZON END-->
                              <section class="elementor-section elementor-top-section elementor-element elementor-element-931c4be elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="931c4be" data-element_type="section">
                                 <div class="elementor-container elementor-column-gap-default">
                                    <div class="elementor-row">
                                       <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a9e44a8" data-id="a9e44a8" data-element_type="column">
                                          <div class="elementor-column-wrap">
                                             <div class="elementor-widget-wrap">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- .entry-content -->
               </div>
               <div id="secondary" class="g1-sidebar g1-sidebar-padded g1-column g1-column-1of3">
                  <aside id="custom_html-10" class="widget_text widget widget_custom_html">
                     <div class="textwidget custom-html-widget">
			<!--AD Body Start-->
									<?=$settings->SidebarAds;?>
								<!--AD Body End-->

			</div>
                  </aside>
               </div>
               <!-- #secondary -->
            </div>
         </div>
      </article>
      <!-- #post-## -->
   </div>
   <!-- #content -->
</div>
<!-- #primary -->