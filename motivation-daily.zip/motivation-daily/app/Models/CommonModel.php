<?php
/**
 * File Created By Shantun
 * Date 14-01-2022
**/

namespace App\Models;

use CodeIgniter\Model;

class CommonModel extends Model
{
        protected $table = '_posts_mst';
        protected $postTerm = '_post_term';
        protected $category = '_term_mst';
        protected $settings = '_settings';
        protected $pages = '_page_mst';
       
        
    function __constructor(){
        parent::__construct();      
        
        $this->db = \Config\Database::connect();
    
    }
       
     public function getAllPosts($sea =null)
    {
        $builder = $this->db->table($this->table." p");
        $builder->join($this->postTerm.' pt', 'pt.PostId = p.ID', 'left');
        $builder->select('p.PostContent,p.PostSlug, p.PostTitle,p.PostThumbUrl,p.PostThumb,pt.CatId,DATE(p.PostUpdated) Date');
        // $builder->like('p.PostTitle',$sea, 'both'); 
        $builder->where("p.PostTitle LIKE '%$sea%' OR p.PostContent LIKE '%$sea%'");
        // $builder->orLike('p.PostContent', $sea, 'both');
        $builder->limit(10, 0);
          $query = $builder->get();
        //   echo $this->db->getLastQuery(); exit;
	  return $query->getResult(); 

    }
    

    public function getPosts($offset=0,$limit=4,$fields=[],$condition=[])
    {
      

        $builder = $this->db->table($this->table." p");
        $builder->join($this->postTerm.' pt', 'pt.PostId = p.ID', 'left');
        $builder->select('p.PostSlug, p.PostTitle,p.PostThumbUrl,p.PostThumb,pt.CatId,DATE(p.PostUpdated) Date, p.PostUpdated ModifiedTime, p.CreationDate PublishedTime');
        if(!empty($fields))
            $builder->select($fields);
        if(!empty($condition))
            $builder->where($condition);
        $builder->orderBy('p.PostUpdated','DESC');
        $builder->limit($limit, $offset);
        $query = $builder->get();
       //echo $this->db->getLastQuery();
        return $query->getResult(); 

    }


    public function getCateogry(){
            
        $categories = $this->db->table($this->category)->get()->getResult();
        $catArray = array();

        foreach ($categories as $key => $value) {
            $catArray[$value->TermId] = array('TermName'=>$value->TermName,'TermSlug'=>$value->TermSlug,'TermImage'=>$value->TermImage);
               
        }
        return $catArray;
    }
    
    public function getSettings()
    {
        return $this->db->table($this->settings)->get()->getResult();
        
    }
     
    public function getPage($condition=[]){

        $builder = $this->db->table($this->pages." p");
        $builder->select('p.PageTitle, p.PageSlug,p.PageContent');
        if(!empty($condition))
            $builder->where($condition);
        $query = $builder->get();
       //echo $this->db->getLastQuery();
        return $query->getResult(); 

    }

    public function pagination($condition=[]){

        $builder = $this->db->table($this->table." p");
        $builder->join($this->postTerm.' pt', 'pt.PostId = p.ID', 'left');
        $builder->select('COUNT(p.ID) COUNT');
        if(!empty($condition))
            $builder->where($condition);
        $query = $builder->get();
        //echo $this->db->getLastQuery();
        return $query->getRow(); 

    }
    public function getFeedArticles(){
	 $builder = $this->db->table($this->table." p");
         $builder->select('p.PostTitle, p.PostSlug,p.PostContent');
         //$builder->limit(1, 0);
         $query = $builder->get();
        return $query->getResult(); 
    }
       
function getNext($postId){
    $builder = $this->db->table($this->table);
    $builder->select('PostSlug,PostTitle,PostThumbUrl');
    $builder->where("ID > $postId")->limit(1);
    return $builder->get()->getRowArray();
}
function getPrevious($postId){
    $builder = $this->db->table($this->table);
    $builder->select('PostSlug,PostTitle,PostThumbUrl');
     $builder->where("ID < $postId")->limit(1);
     return $builder->get()->getRowArray();
}
    


}